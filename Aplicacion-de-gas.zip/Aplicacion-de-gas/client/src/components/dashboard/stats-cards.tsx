import { useDashboard } from "@/hooks/use-dashboard";
import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Clock, CheckCircle, AlertTriangle, Users } from "lucide-react";

export default function StatsCards() {
  const { data: stats, isLoading } = useDashboard();

  const formatMonto = (monto: string) => {
    const amount = parseFloat(monto);
    return new Intl.NumberFormat('es-AR', {
      style: 'currency',
      currency: 'ARS'
    }).format(amount);
  };

  if (isLoading) {
    return (
      <section className="px-4 py-6">
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          {Array.from({ length: 4 }).map((_, i) => (
            <Skeleton key={i} className="h-24 w-full" />
          ))}
        </div>
      </section>
    );
  }

  const statsData = [
    {
      title: "Total por Cobrar",
      value: formatMonto(stats?.totalPendiente || "0"),
      icon: Clock,
      bgColor: "bg-primary/10",
      iconColor: "text-primary",
      valueColor: "text-gray-900"
    },
    {
      title: "Cobrado Hoy",
      value: formatMonto(stats?.cobradoHoy || "0"),
      icon: CheckCircle,
      bgColor: "bg-success/10",
      iconColor: "text-success",
      valueColor: "text-success"
    },
    {
      title: "Vencidos",
      value: formatMonto(stats?.vencidos || "0"),
      icon: AlertTriangle,
      bgColor: "bg-destructive/10",
      iconColor: "text-destructive",
      valueColor: "text-destructive"
    },
    {
      title: "Clientes Activos",
      value: stats?.clientesActivos || 0,
      icon: Users,
      bgColor: "bg-gray-100",
      iconColor: "text-gray-600",
      valueColor: "text-gray-900"
    }
  ];

  return (
    <section className="px-4 py-6">
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {statsData.map((stat) => {
          const Icon = stat.icon;
          return (
            <Card key={stat.title} className="bg-white shadow-sm border border-gray-100">
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-600 mb-1">{stat.title}</p>
                    <p className={`text-2xl font-mono font-semibold ${stat.valueColor}`}>
                      {stat.value}
                    </p>
                  </div>
                  <div className={`w-10 h-10 ${stat.bgColor} rounded-lg flex items-center justify-center`}>
                    <Icon className={`h-5 w-5 ${stat.iconColor}`} />
                  </div>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>
    </section>
  );
}
