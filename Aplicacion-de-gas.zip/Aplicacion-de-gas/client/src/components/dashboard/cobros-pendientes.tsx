import { useCobros } from "@/hooks/use-cobros";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Calendar, Phone } from "lucide-react";
import { format } from "date-fns";
import { es } from "date-fns/locale";
import { useLocation } from "wouter";

export default function CobrosPendientes() {
  const { data: cobros, isLoading } = useCobros();
  const [, setLocation] = useLocation();

  const formatMonto = (monto: string) => {
    const amount = parseFloat(monto);
    return new Intl.NumberFormat('es-AR', {
      style: 'currency',
      currency: 'ARS'
    }).format(amount);
  };

  const getEstadoBadge = (estado: string, fechaVencimiento: string) => {
    const now = new Date();
    const vencimiento = new Date(fechaVencimiento);
    
    if (vencimiento < now && estado === "pendiente") {
      return <Badge className="bg-destructive text-white">Vencido</Badge>;
    }
    
    if (estado === "pendiente") {
      const diffTime = vencimiento.getTime() - now.getTime();
      const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
      
      if (diffDays <= 7) {
        return <Badge className="bg-warning text-white">Próximo</Badge>;
      }
      
      return <Badge className="bg-gray-500 text-white">Pendiente</Badge>;
    }
    
    return <Badge variant="outline">{estado}</Badge>;
  };

  const handleContactClient = (telefono: string) => {
    const cleanPhone = telefono.replace(/[^0-9]/g, '');
    window.open(`https://wa.me/${cleanPhone}`, '_blank');
  };

  if (isLoading) {
    return (
      <section className="px-4 mb-6">
        <Card>
          <CardHeader>
            <Skeleton className="h-6 w-40" />
          </CardHeader>
          <CardContent className="space-y-3">
            {Array.from({ length: 3 }).map((_, i) => (
              <Skeleton key={i} className="h-20 w-full" />
            ))}
          </CardContent>
        </Card>
      </section>
    );
  }

  const cobrosPendientes = cobros?.filter(cobro => 
    cobro.estado === "pendiente" || cobro.estado === "parcial"
  ).slice(0, 3) || [];

  return (
    <section className="px-4 mb-6">
      <Card className="bg-white shadow-sm border border-gray-100">
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="text-lg font-semibold text-gray-900">
              Cobros Pendientes
            </CardTitle>
            <Button
              variant="ghost"
              size="sm"
              className="text-sm text-primary hover:text-primary/80 font-medium"
              onClick={() => setLocation("/cobros")}
            >
              Ver todos
            </Button>
          </div>
        </CardHeader>
        <CardContent className="p-0">
          <div className="divide-y divide-gray-100">
            {cobrosPendientes.map((cobro) => (
              <div key={cobro.id} className="p-4 hover:bg-gray-50 transition-colors">
                <div className="flex items-center justify-between">
                  <div className="flex-1">
                    <div className="flex items-center space-x-3 mb-2">
                      <h3 className="font-medium text-gray-900">{cobro.cliente.nombre}</h3>
                      {getEstadoBadge(cobro.estado, cobro.fechaVencimiento)}
                    </div>
                    <p className="text-sm text-gray-600 mb-1">{cobro.descripcion}</p>
                    <div className="flex items-center space-x-4 text-xs text-gray-500">
                      <span className="flex items-center gap-1">
                        <Calendar className="h-3 w-3" />
                        Vence: {format(new Date(cobro.fechaVencimiento), 'dd/MM/yyyy', { locale: es })}
                      </span>
                      <span className="flex items-center gap-1">
                        <Phone className="h-3 w-3" />
                        {cobro.cliente.telefono}
                      </span>
                    </div>
                  </div>
                  <div className="text-right ml-4">
                    <p className="text-lg font-mono font-semibold text-gray-900">
                      {formatMonto(cobro.monto)}
                    </p>
                    <Button
                      variant="ghost"
                      size="sm"
                      className="mt-1 text-xs text-primary hover:text-primary/80 font-medium"
                      onClick={() => handleContactClient(cobro.cliente.telefono)}
                    >
                      Contactar
                    </Button>
                  </div>
                </div>
              </div>
            ))}
            
            {cobrosPendientes.length === 0 && (
              <div className="p-8 text-center">
                <p className="text-gray-500">No hay cobros pendientes</p>
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    </section>
  );
}
