import { useClientes } from "@/hooks/use-clientes";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { useLocation } from "wouter";
import { formatDistanceToNow } from "date-fns";
import { es } from "date-fns/locale";

export default function ClientesRecientes() {
  const { data: clientesData, isLoading } = useClientes();
  const [, setLocation] = useLocation();

  const formatMonto = (monto: string) => {
    const amount = parseFloat(monto);
    return new Intl.NumberFormat('es-AR', {
      style: 'currency',
      currency: 'ARS'
    }).format(amount);
  };

  const getInitials = (nombre: string) => {
    return nombre
      .split(' ')
      .map(word => word[0])
      .join('')
      .toUpperCase()
      .slice(0, 2);
  };

  const getInitialsColor = (index: number) => {
    const colors = [
      "bg-primary/10 text-primary",
      "bg-success/10 text-success", 
      "bg-warning/10 text-warning",
      "bg-purple-100 text-purple-600",
      "bg-pink-100 text-pink-600"
    ];
    return colors[index % colors.length];
  };

  if (isLoading) {
    return (
      <section className="px-4 mb-20">
        <Card>
          <CardHeader>
            <Skeleton className="h-6 w-40" />
          </CardHeader>
          <CardContent className="space-y-3">
            {Array.from({ length: 3 }).map((_, i) => (
              <Skeleton key={i} className="h-16 w-full" />
            ))}
          </CardContent>
        </Card>
      </section>
    );
  }

  // Get the most recent clients (by creation date)
  const clientesRecientes = clientesData?.slice(0, 3) || [];

  return (
    <section className="px-4 mb-20">
      <Card className="bg-white shadow-sm border border-gray-100">
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="text-lg font-semibold text-gray-900">
              Clientes Recientes
            </CardTitle>
            <Button
              variant="ghost"
              size="sm"
              className="text-sm text-primary hover:text-primary/80 font-medium"
              onClick={() => setLocation("/clientes")}
            >
              Ver todos
            </Button>
          </div>
        </CardHeader>
        <CardContent className="p-0">
          <div className="divide-y divide-gray-100">
            {clientesRecientes.map((cliente, index) => (
              <div key={cliente.id} className="p-4 hover:bg-gray-50 transition-colors">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <div className={`w-10 h-10 rounded-full flex items-center justify-center ${getInitialsColor(index)}`}>
                      <span className="text-sm font-semibold">
                        {getInitials(cliente.nombre)}
                      </span>
                    </div>
                    <div>
                      <h3 className="font-medium text-gray-900">{cliente.nombre}</h3>
                      <p className="text-sm text-gray-600">{cliente.telefono}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-sm font-medium text-gray-900">
                      {formatMonto(cliente.deudaTotal)}
                    </p>
                    <p className="text-xs text-gray-500">
                      {cliente.fechaCreacion 
                        ? formatDistanceToNow(new Date(cliente.fechaCreacion), { 
                            addSuffix: true, 
                            locale: es 
                          })
                        : "Sin fecha"
                      }
                    </p>
                  </div>
                </div>
              </div>
            ))}
            
            {clientesRecientes.length === 0 && (
              <div className="p-8 text-center">
                <p className="text-gray-500">No hay clientes registrados</p>
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    </section>
  );
}
