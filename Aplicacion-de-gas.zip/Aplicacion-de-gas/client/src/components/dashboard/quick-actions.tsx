import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { UserPlus, PlusCircle, CreditCard, BarChart3 } from "lucide-react";
import ClienteForm from "@/components/forms/cliente-form";
import CobroForm from "@/components/forms/cobro-form";
import PagoForm from "@/components/forms/pago-form";
import { useLocation } from "wouter";

type ActionType = "cliente" | "cobro" | "pago" | null;

export default function QuickActions() {
  const [activeDialog, setActiveDialog] = useState<ActionType>(null);
  const [, setLocation] = useLocation();

  const handleAction = (type: ActionType) => {
    if (type === null) {
      setLocation("/reportes");
    } else {
      setActiveDialog(type);
    }
  };

  const closeDialog = () => {
    setActiveDialog(null);
  };

  const getDialogTitle = () => {
    switch (activeDialog) {
      case "cliente": return "Nuevo Cliente";
      case "cobro": return "Nuevo Cobro";
      case "pago": return "Registrar Pago";
      default: return "";
    }
  };

  const renderDialogContent = () => {
    switch (activeDialog) {
      case "cliente": return <ClienteForm onSuccess={closeDialog} />;
      case "cobro": return <CobroForm onSuccess={closeDialog} />;
      case "pago": return <PagoForm onSuccess={closeDialog} />;
      default: return null;
    }
  };

  const actions = [
    {
      type: "cliente" as const,
      icon: UserPlus,
      label: "Nuevo Cliente",
      bgColor: "bg-primary/10 hover:bg-primary/20",
      textColor: "text-primary"
    },
    {
      type: "cobro" as const,
      icon: PlusCircle,
      label: "Nuevo Cobro",
      bgColor: "bg-warning/10 hover:bg-warning/20",
      textColor: "text-warning"
    },
    {
      type: "pago" as const,
      icon: CreditCard,
      label: "Registrar Pago",
      bgColor: "bg-success/10 hover:bg-success/20",
      textColor: "text-success"
    },
    {
      type: null,
      icon: BarChart3,
      label: "Reportes",
      bgColor: "bg-gray-100 hover:bg-gray-200",
      textColor: "text-gray-600"
    }
  ];

  return (
    <>
      <section className="px-4 mb-6">
        <Card className="bg-white shadow-sm border border-gray-100">
          <CardHeader>
            <CardTitle className="text-lg font-semibold text-gray-900">
              Acciones Rápidas
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              {actions.map((action, index) => {
                const Icon = action.icon;
                return (
                  <Button
                    key={index}
                    variant="ghost"
                    className={`flex flex-col items-center p-4 h-auto ${action.bgColor} transition-colors`}
                    onClick={() => handleAction(action.type)}
                  >
                    <Icon className={`${action.textColor} text-xl mb-2`} />
                    <span className={`text-sm font-medium ${action.textColor}`}>
                      {action.label}
                    </span>
                  </Button>
                );
              })}
            </div>
          </CardContent>
        </Card>
      </section>

      <Dialog open={!!activeDialog} onOpenChange={() => setActiveDialog(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{getDialogTitle()}</DialogTitle>
          </DialogHeader>
          {renderDialogContent()}
        </DialogContent>
      </Dialog>
    </>
  );
}
