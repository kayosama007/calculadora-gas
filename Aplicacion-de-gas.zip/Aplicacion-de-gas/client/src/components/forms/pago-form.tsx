import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { usePagos } from "@/hooks/use-pagos";
import { useCobros } from "@/hooks/use-cobros";
import { insertPagoSchema, type InsertPago } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { useToast } from "@/hooks/use-toast";

interface PagoFormProps {
  onSuccess?: () => void;
}

export default function PagoForm({ onSuccess }: PagoFormProps) {
  const { createPago } = usePagos();
  const { data: cobros } = useCobros();
  const { toast } = useToast();

  const form = useForm<InsertPago>({
    resolver: zodResolver(insertPagoSchema),
    defaultValues: {
      cobroId: 0,
      monto: "0",
      metodoPago: "",
      notas: "",
    },
  });

  const onSubmit = (data: InsertPago) => {
    createPago.mutate(data, {
      onSuccess: () => {
        toast({
          title: "Pago registrado",
          description: "El pago ha sido registrado exitosamente.",
        });
        onSuccess?.();
      },
      onError: (error: any) => {
        toast({
          title: "Error",
          description: error.message || "No se pudo registrar el pago.",
          variant: "destructive",
        });
      },
    });
  };

  // Filter only pending or partial cobros
  const cobrosDisponibles = cobros?.filter(cobro => 
    cobro.estado === "pendiente" || cobro.estado === "parcial"
  ) || [];

  const formatMonto = (monto: string) => {
    const amount = parseFloat(monto);
    return new Intl.NumberFormat('es-AR', {
      style: 'currency',
      currency: 'ARS'
    }).format(amount);
  };

  const metodosPago = [
    "Efectivo",
    "Transferencia bancaria",
    "Débito",
    "Crédito",
    "Cheque",
    "Mercado Pago",
    "Otro"
  ];

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
        <FormField
          control={form.control}
          name="cobroId"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Cobro *</FormLabel>
              <Select 
                onValueChange={(value) => field.onChange(parseInt(value))} 
                value={field.value?.toString()}
              >
                <FormControl>
                  <SelectTrigger>
                    <SelectValue placeholder="Seleccionar cobro" />
                  </SelectTrigger>
                </FormControl>
                <SelectContent>
                  {cobrosDisponibles.map((cobro) => (
                    <SelectItem key={cobro.id} value={cobro.id.toString()}>
                      <div className="flex flex-col items-start">
                        <span>{cobro.cliente.nombre}</span>
                        <span className="text-xs text-gray-500">
                          {cobro.descripcion} - {formatMonto(cobro.monto)}
                        </span>
                      </div>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <FormMessage />
            </FormItem>
          )}
        />

        <FormField
          control={form.control}
          name="monto"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Monto del pago *</FormLabel>
              <FormControl>
                <Input 
                  type="number" 
                  step="0.01"
                  placeholder="0.00"
                  {...field} 
                />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <FormField
          control={form.control}
          name="metodoPago"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Método de pago *</FormLabel>
              <Select onValueChange={field.onChange} value={field.value}>
                <FormControl>
                  <SelectTrigger>
                    <SelectValue placeholder="Seleccionar método" />
                  </SelectTrigger>
                </FormControl>
                <SelectContent>
                  {metodosPago.map((metodo) => (
                    <SelectItem key={metodo} value={metodo}>
                      {metodo}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <FormMessage />
            </FormItem>
          )}
        />

        <FormField
          control={form.control}
          name="notas"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Notas</FormLabel>
              <FormControl>
                <Textarea 
                  placeholder="Información adicional sobre el pago..."
                  className="resize-none"
                  rows={3}
                  {...field} 
                />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <div className="flex gap-3 pt-4">
          <Button
            type="button"
            variant="outline"
            className="flex-1"
            onClick={onSuccess}
          >
            Cancelar
          </Button>
          <Button
            type="submit"
            className="flex-1 bg-success hover:bg-success/90 text-white"
            disabled={createPago.isPending}
          >
            {createPago.isPending ? "Registrando..." : "Registrar Pago"}
          </Button>
        </div>
      </form>
    </Form>
  );
}
