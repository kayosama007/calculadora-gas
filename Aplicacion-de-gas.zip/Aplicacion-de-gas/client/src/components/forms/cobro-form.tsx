import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useCobros } from "@/hooks/use-cobros";
import { useClientes } from "@/hooks/use-clientes";
import { insertCobroSchema, type InsertCobro } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { useToast } from "@/hooks/use-toast";
import { format } from "date-fns";

interface CobroFormProps {
  onSuccess?: () => void;
}

export default function CobroForm({ onSuccess }: CobroFormProps) {
  const { createCobro } = useCobros();
  const { data: clientes } = useClientes();
  const { toast } = useToast();

  const form = useForm<InsertCobro>({
    resolver: zodResolver(insertCobroSchema),
    defaultValues: {
      clienteId: 0,
      descripcion: "",
      monto: "0",
      fechaVencimiento: new Date(),
    },
  });

  const onSubmit = (data: InsertCobro) => {
    createCobro.mutate(data, {
      onSuccess: () => {
        toast({
          title: "Cobro creado",
          description: "El cobro ha sido registrado exitosamente.",
        });
        onSuccess?.();
      },
      onError: (error: any) => {
        toast({
          title: "Error",
          description: error.message || "No se pudo crear el cobro.",
          variant: "destructive",
        });
      },
    });
  };

  // Get tomorrow's date as default
  const tomorrow = new Date();
  tomorrow.setDate(tomorrow.getDate() + 1);
  const defaultDate = format(tomorrow, 'yyyy-MM-dd');

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
        <FormField
          control={form.control}
          name="clienteId"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Cliente *</FormLabel>
              <Select 
                onValueChange={(value) => field.onChange(parseInt(value))} 
                value={field.value?.toString()}
              >
                <FormControl>
                  <SelectTrigger>
                    <SelectValue placeholder="Seleccionar cliente" />
                  </SelectTrigger>
                </FormControl>
                <SelectContent>
                  {clientes?.map((cliente) => (
                    <SelectItem key={cliente.id} value={cliente.id.toString()}>
                      {cliente.nombre}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <FormMessage />
            </FormItem>
          )}
        />

        <FormField
          control={form.control}
          name="descripcion"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Descripción *</FormLabel>
              <FormControl>
                <Textarea 
                  placeholder="Ej: Pago mensual - Noviembre 2024"
                  className="resize-none"
                  rows={2}
                  {...field} 
                />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <FormField
          control={form.control}
          name="monto"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Monto *</FormLabel>
              <FormControl>
                <Input 
                  type="number" 
                  step="0.01"
                  placeholder="0.00"
                  {...field} 
                />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <FormField
          control={form.control}
          name="fechaVencimiento"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Fecha de vencimiento *</FormLabel>
              <FormControl>
                <Input 
                  type="date"
                  defaultValue={defaultDate}
                  onChange={(e) => field.onChange(new Date(e.target.value))}
                />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <div className="flex gap-3 pt-4">
          <Button
            type="button"
            variant="outline"
            className="flex-1"
            onClick={onSuccess}
          >
            Cancelar
          </Button>
          <Button
            type="submit"
            className="flex-1 bg-warning hover:bg-warning/90 text-white"
            disabled={createCobro.isPending}
          >
            {createCobro.isPending ? "Guardando..." : "Crear Cobro"}
          </Button>
        </div>
      </form>
    </Form>
  );
}
