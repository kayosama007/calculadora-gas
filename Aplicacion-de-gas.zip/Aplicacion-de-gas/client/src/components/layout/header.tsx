import { Fuel, User, Settings, Zap } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useUser } from "@/contexts/user-context";
import { useLocation } from "wouter";
import DonationModal from "@/components/modals/donation-modal";

export default function Header() {
  const { usuario, isAuthenticated } = useUser();
  const [, setLocation] = useLocation();

  if (!isAuthenticated) {
    return null;
  }

  return (
    <header className="bg-white border-b border-gray-200 px-4 py-3">
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-blue-600 rounded-lg flex items-center justify-center relative shadow-md">
            <Fuel className="h-6 w-6 text-white" />
            <Zap className="h-3 w-3 text-yellow-300 absolute -bottom-0.5 -right-0.5" />
          </div>
          <div>
            <h1 className="text-lg font-semibold text-gray-900">calculadoradegas</h1>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <DonationModal />
          {usuario?.esAdmin && (
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setLocation("/admin")}
              data-testid="button-admin-panel"
              title="Panel de administrador"
            >
              <Settings className="h-4 w-4" />
            </Button>
          )}
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setLocation("/perfil")}
            className="flex items-center space-x-2"
            data-testid="button-profile"
          >
            <User className="h-4 w-4" />
            <span className="hidden sm:block">{usuario?.nombre}</span>
          </Button>
        </div>
      </div>
    </header>
  );
}