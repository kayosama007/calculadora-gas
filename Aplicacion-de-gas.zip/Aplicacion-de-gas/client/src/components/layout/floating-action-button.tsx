import { Calculator } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useLocation } from "wouter";
import { useUser } from "@/contexts/user-context";

export default function FloatingActionButton() {
  const [location, setLocation] = useLocation();
  const { isAuthenticated } = useUser();

  if (!isAuthenticated || location === "/calculadora") {
    return null;
  }

  return (
    <Button
      onClick={() => setLocation("/calculadora")}
      className="fixed bottom-20 right-4 h-14 w-14 rounded-full shadow-lg bg-primary hover:bg-primary/90 z-50"
      size="icon"
    >
      <Calculator className="h-6 w-6 text-white" />
    </Button>
  );
}