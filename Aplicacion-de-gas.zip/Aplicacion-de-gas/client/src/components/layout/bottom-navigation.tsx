import { Home, Calculator, Fuel, History, User, MapPin } from "lucide-react";
import { useLocation } from "wouter";
import { useUser } from "@/contexts/user-context";

export default function BottomNavigation() {
  const [location, setLocation] = useLocation();
  const { isAuthenticated } = useUser();

  if (!isAuthenticated) {
    return null;
  }

  const navigationItems = [
    { icon: Home, label: "Inicio", path: "/" },
    { icon: Calculator, label: "Calcular", path: "/calculadora" },
    { icon: Fuel, label: "Tanques", path: "/tanques" },
    { icon: MapPin, label: "Pipas", path: "/pipas" },
    { icon: History, label: "Historial", path: "/historial" },
    { icon: User, label: "Perfil", path: "/perfil" },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 px-4 py-2">
      <div className="flex justify-around">
        {navigationItems.map((item) => {
          const Icon = item.icon;
          const isActive = location === item.path;
          
          return (
            <button
              key={item.path}
              onClick={() => setLocation(item.path)}
              className={`flex flex-col items-center py-1 px-2 rounded-lg transition-colors ${
                isActive
                  ? "text-primary bg-primary/10"
                  : "text-gray-600 hover:text-primary hover:bg-gray-50"
              }`}
            >
              <Icon className="h-5 w-5 mb-1" />
              <span className="text-xs font-medium">{item.label}</span>
            </button>
          );
        })}
      </div>
    </nav>
  );
}