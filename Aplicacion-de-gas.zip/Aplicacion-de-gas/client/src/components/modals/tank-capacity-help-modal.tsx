import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { HelpCircle } from "lucide-react";
import tankDiagramImage from "@assets/ChatGPT Image 27 nov 2025, 02_07_31 p.m._1764274128304.png";
import instructionsImage from "@assets/ChatGPT Image 27 nov 2025, 12_50_43 p.m._1764274128304.png";

interface TankCapacityHelpModalProps {
  open: boolean;
  onClose: () => void;
}

export default function TankCapacityHelpModal({ open, onClose }: TankCapacityHelpModalProps) {
  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <HelpCircle className="h-5 w-5 text-primary" />
            ¿Dónde encontrar la capacidad del tanque?
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-6 py-4">
          <div>
            <p className="text-gray-700 mb-4 font-medium">
              La capacidad está etiquetada directamente en el tanque de gas. Busca una placa o sticker que indique "CAPACIDAD" seguido de un número y la letra "L" (litros).
            </p>
          </div>

          <div className="space-y-3">
            <h3 className="font-semibold text-gray-900">Partes del tanque estacionario:</h3>
            <img 
              src={tankDiagramImage} 
              alt="Partes del tanque estacionario de gas" 
              className="w-full rounded-lg border border-gray-200"
            />
          </div>

          <div className="space-y-3">
            <h3 className="font-semibold text-gray-900">Instrucciones:</h3>
            <img 
              src={instructionsImage} 
              alt="Calculadora de Gas - Dónde encontrar la capacidad" 
              className="w-full rounded-lg border border-gray-200"
            />
          </div>

          <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
            <p className="text-sm text-blue-900">
              <span className="font-semibold">💡 Tip:</span> Las capacidades más comunes son 45L, 60L, 90L y 480L. 
              Si no encuentras la etiqueta, pregunta al distribuidor de gas o revisa tu último recibo de compra.
            </p>
          </div>
        </div>

        <DialogFooter>
          <Button onClick={onClose} className="w-full bg-primary hover:bg-primary/90">
            Entendido
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
