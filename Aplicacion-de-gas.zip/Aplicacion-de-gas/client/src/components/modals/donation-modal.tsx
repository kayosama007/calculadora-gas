import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Heart, Copy, Check } from "lucide-react";

export default function DonationModal() {
  const [copied, setCopied] = useState(false);

  const handleCopy = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <Dialog>
      <DialogTrigger asChild>
        <Button
          className="bg-gradient-to-r from-red-500 to-red-600 hover:from-red-600 hover:to-red-700 text-white font-bold px-4 py-2 animate-pulse shadow-lg"
          data-testid="button-donate"
          title="Donar"
        >
          <Heart className="h-5 w-5 mr-2 fill-current" />
          <span className="hidden sm:inline">Donar</span>
          <span className="sm:hidden">❤️</span>
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-red-600">
            <Heart className="h-5 w-5" />
            Ayuda a mejorar nuestro desarrollo
          </DialogTitle>
          <DialogDescription className="text-gray-700 pt-2">
            Tu donación nos ayuda a mejorar continuamente esta app y hacer que más usuarios puedan utilizarla totalmente gratis.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4 py-4">
          <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 space-y-3">
            <div>
              <p className="text-sm font-medium text-gray-700 mb-1">Banco:</p>
              <p className="text-base font-semibold text-gray-900">BBVA México</p>
            </div>

            <div>
              <p className="text-sm font-medium text-gray-700 mb-1">CLABE:</p>
              <div className="flex items-center gap-2">
                <code className="text-sm font-mono bg-white px-3 py-2 rounded border border-blue-300 flex-1 text-gray-900">
                  012180004799747847
                </code>
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => handleCopy("012180004799747847")}
                  className="px-3"
                  data-testid="button-copy-clabe"
                >
                  {copied ? <Check className="h-4 w-4 text-green-600" /> : <Copy className="h-4 w-4" />}
                </Button>
              </div>
            </div>

            <div>
              <p className="text-sm font-medium text-gray-700 mb-1">Titular:</p>
              <p className="text-base font-semibold text-gray-900">Ing Isai G.R</p>
            </div>

            <div>
              <p className="text-sm font-medium text-gray-700 mb-1">Concepto:</p>
              <div className="flex items-center gap-2">
                <code className="text-sm font-mono bg-white px-3 py-2 rounded border border-blue-300 flex-1 text-gray-900">
                  DonaGascal
                </code>
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => handleCopy("DonaGascal")}
                  className="px-3"
                  data-testid="button-copy-concept"
                >
                  {copied ? <Check className="h-4 w-4 text-green-600" /> : <Copy className="h-4 w-4" />}
                </Button>
              </div>
            </div>
          </div>

          <div className="bg-green-50 border border-green-200 rounded-lg p-3">
            <p className="text-sm text-green-900">
              ✨ <strong>¡Gracias por tu contribución!</strong> Cada donación nos acerca a mejorar y expandir esta herramienta.
            </p>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
