import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { CheckCircle, XCircle } from "lucide-react";

interface TermsModalProps {
  open: boolean;
  onAccept: () => void;
  onReject: () => void;
}

export default function TermsModal({ open, onAccept, onReject }: TermsModalProps) {
  return (
    <Dialog open={open}>
      <DialogContent className="sm:max-w-2xl max-h-screen overflow-hidden flex flex-col">
        <DialogHeader>
          <DialogTitle>Términos y Condiciones</DialogTitle>
          <DialogDescription>
            Por favor, lee y acepta nuestros términos antes de continuar
          </DialogDescription>
        </DialogHeader>

        <ScrollArea className="flex-1 pr-4 py-4">
          <div className="space-y-4 text-sm text-gray-700">
            <div>
              <h3 className="font-bold text-gray-900 mb-2">1. Propósito de la Aplicación</h3>
              <p>
                calculadoradegas es una herramienta de cálculo y gestión personal para usuarios que necesitan llevar un registro de su consumo y gastos de gas. 
                Esta aplicación NO está diseñada para controlar, monitorear o ejercer influencia sobre empresas distribuidoras de gas o proveedores.
              </p>
            </div>

            <div>
              <h3 className="font-bold text-gray-900 mb-2">2. Protección a Distribuidoras y Proveedores</h3>
              <p>
                calculadoradegas es una herramienta personal. No es un sistema de control, vigilancia o coordinación contra empresas de gas. 
                Cualquier uso con intención de perjudicar, boicotear o coordinar acciones contra distribuidoras o proveedores está estrictamente prohibido.
              </p>
            </div>

            <div>
              <h3 className="font-bold text-gray-900 mb-2">3. Uso Responsable</h3>
              <p>
                El usuario se compromete a utilizar esta aplicación exclusivamente para fines personales y lícitos. Los datos son privados y personales.
                No está permitido:
              </p>
              <ul className="list-disc list-inside mt-2 space-y-1 ml-2">
                <li>Usar la aplicación para coordinar acciones colectivas contra proveedores</li>
                <li>Compartir información para fines ilícitos o discriminatorios</li>
                <li>Intentar evadir pagos legítimos de servicios</li>
                <li>Falsificar datos o información</li>
                <li>Usar la aplicación para actividades delictivas</li>
              </ul>
            </div>

            <div>
              <h3 className="font-bold text-gray-900 mb-2">4. Privacidad y Seguridad</h3>
              <p>
                Tus datos personales y de consumo son confidenciales. No compartiremos tu información con distribuidoras, proveedores u otras empresas sin tu consentimiento explícito.
              </p>
            </div>

            <div>
              <h3 className="font-bold text-gray-900 mb-2">5. Responsabilidad del Usuario</h3>
              <p>
                El usuario es responsable de:
              </p>
              <ul className="list-disc list-inside mt-2 space-y-1 ml-2">
                <li>La precisión de la información que ingresa</li>
                <li>Cumplir con leyes locales aplicables</li>
                <li>No violar derechos de terceros</li>
                <li>Usar la aplicación de forma ética y legal</li>
              </ul>
            </div>

            <div>
              <h3 className="font-bold text-gray-900 mb-2">6. Prohibición de Mal Uso</h3>
              <p>
                Está expresamente prohibido:
              </p>
              <ul className="list-disc list-inside mt-2 space-y-1 ml-2">
                <li>Acceder sin autorización a sistemas o datos de terceros</li>
                <li>Crear múltiples cuentas para manipular datos</li>
                <li>Usar bots o herramientas automatizadas para explotar la aplicación</li>
                <li>Transmitir virus, malware o código malicioso</li>
                <li>Hostigar, acosar o amenazar a otros usuarios o empresas</li>
              </ul>
            </div>

            <div>
              <h3 className="font-bold text-gray-900 mb-2">7. Consecuencias del Incumplimiento</h3>
              <p>
                El incumplimiento de estos términos puede resultar en:
              </p>
              <ul className="list-disc list-inside mt-2 space-y-1 ml-2">
                <li>Suspensión o eliminación de la cuenta</li>
                <li>Restricción de acceso a la aplicación</li>
                <li>Reportes a autoridades competentes si se cometen delitos</li>
                <li>Acciones legales según corresponda</li>
              </ul>
            </div>

            <div>
              <h3 className="font-bold text-gray-900 mb-2">8. Descargo de Responsabilidad</h3>
              <p>
                GasCalc se proporciona "tal cual" sin garantías de precisión absoluta. El usuario utiliza la aplicación bajo su propio riesgo.
                No seremos responsables por decisiones tomadas basadas en información de la aplicación.
              </p>
            </div>

            <div className="bg-yellow-50 border border-yellow-200 rounded p-3 mt-4">
              <p className="text-xs font-semibold text-yellow-900">
                ⚠️ Al hacer clic en "Acepto", confirmas que has leído y entendido estos términos y que aceptas estar vinculado por ellos.
              </p>
            </div>
          </div>
        </ScrollArea>

        <div className="flex gap-2 pt-4 border-t">
          <Button
            variant="outline"
            onClick={onReject}
            className="flex-1"
            data-testid="button-reject-terms"
          >
            <XCircle className="h-4 w-4 mr-2" />
            Rechazar
          </Button>
          <Button
            onClick={onAccept}
            className="flex-1 bg-green-600 hover:bg-green-700"
            data-testid="button-accept-terms"
          >
            <CheckCircle className="h-4 w-4 mr-2" />
            Acepto los términos
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
