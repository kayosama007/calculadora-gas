import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { MapPin } from "lucide-react";

interface PipasInfoModalProps {
  open: boolean;
  onClose: () => void;
}

export default function PipasInfoModal({ open, onClose }: PipasInfoModalProps) {
  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-lg">
            <span className="text-xl">📍</span>
            ¿Por qué registrar pipas?
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-4 py-4">
          <p className="text-gray-700 leading-relaxed text-sm">
            El registro de pipas ayuda a usuarios como tú a encontrar nuevas opciones de proveedores de gas. Según tu ubicación y la ubicación que otros usuarios registren, verás las pipas más cercanas a ti. Comparte los proveedores que conoces para ayudar a tu comunidad.
          </p>

          <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 space-y-2">
            <p className="text-sm font-medium text-blue-900">💡 Beneficios:</p>
            <ul className="text-xs text-blue-800 space-y-1 ml-4">
              <li>• Descubre pipas cercanas por código postal y ciudad</li>
              <li>• Acceso a calificaciones de confiabilidad</li>
              <li>• Ayudas a tu comunidad compartiendo opciones</li>
            </ul>
          </div>
        </div>

        <DialogFooter>
          <Button onClick={onClose} className="w-full bg-primary hover:bg-primary/90">
            Entendido
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
