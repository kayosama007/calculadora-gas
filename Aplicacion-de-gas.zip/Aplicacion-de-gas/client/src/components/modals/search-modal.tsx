import { useState, useEffect } from "react";
import { Dialog, DialogContent } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { useClientes } from "@/hooks/use-clientes";
import { useCobros } from "@/hooks/use-cobros";
import { ArrowLeft, Search, User, DollarSign, Phone } from "lucide-react";

interface SearchModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function SearchModal({ isOpen, onClose }: SearchModalProps) {
  const [searchQuery, setSearchQuery] = useState("");
  const { searchClientes } = useClientes();
  const { data: cobros } = useCobros();

  useEffect(() => {
    if (!isOpen) {
      setSearchQuery("");
    }
  }, [isOpen]);

  const handleSearch = (query: string) => {
    setSearchQuery(query);
    if (query.trim().length > 2) {
      searchClientes.mutate(query);
    }
  };

  const handleContactClient = (telefono: string) => {
    const cleanPhone = telefono.replace(/[^0-9]/g, '');
    window.open(`https://wa.me/${cleanPhone}`, '_blank');
    onClose();
  };

  const formatMonto = (monto: string) => {
    const amount = parseFloat(monto);
    return new Intl.NumberFormat('es-AR', {
      style: 'currency',
      currency: 'ARS'
    }).format(amount);
  };

  // Filter cobros based on search query
  const filteredCobros = searchQuery.trim().length > 2 
    ? cobros?.filter(cobro => 
        cobro.cliente.nombre.toLowerCase().includes(searchQuery.toLowerCase()) ||
        cobro.descripcion.toLowerCase().includes(searchQuery.toLowerCase())
      ).slice(0, 5)
    : [];

  const showResults = searchQuery.trim().length > 2;
  const hasResults = (searchClientes.data?.length || 0) > 0 || (filteredCobros?.length || 0) > 0;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="p-0 max-w-full h-full sm:max-w-lg sm:h-auto">
        <div className="flex flex-col h-full">
          {/* Header */}
          <div className="p-4 border-b border-gray-200">
            <div className="flex items-center space-x-3">
              <Button
                variant="ghost"
                size="sm"
                className="p-0 text-gray-500 hover:text-gray-700"
                onClick={onClose}
              >
                <ArrowLeft className="h-5 w-5" />
              </Button>
              <div className="flex-1 relative">
                <Input
                  placeholder="Buscar clientes, cobros..."
                  value={searchQuery}
                  onChange={(e) => handleSearch(e.target.value)}
                  className="pl-10 pr-4"
                  autoFocus
                />
                <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
              </div>
            </div>
          </div>

          {/* Content */}
          <div className="flex-1 p-4 overflow-y-auto">
            {!showResults && (
              <div className="text-center py-8">
                <Search className="h-12 w-12 text-gray-300 mx-auto mb-3" />
                <p className="text-sm text-gray-500">
                  Ingresa al menos 3 caracteres para buscar
                </p>
              </div>
            )}

            {showResults && !hasResults && (
              <div className="text-center py-8">
                <p className="text-sm text-gray-500">
                  No se encontraron resultados para "{searchQuery}"
                </p>
              </div>
            )}

            {showResults && hasResults && (
              <div className="space-y-6">
                {/* Clientes Results */}
                {searchClientes.data && searchClientes.data.length > 0 && (
                  <div>
                    <h3 className="text-sm font-medium text-gray-900 mb-3 flex items-center gap-2">
                      <User className="h-4 w-4" />
                      Clientes
                    </h3>
                    <div className="space-y-2">
                      {searchClientes.data.slice(0, 5).map((cliente) => (
                        <div
                          key={cliente.id}
                          className="p-3 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors cursor-pointer"
                          onClick={() => handleContactClient(cliente.telefono)}
                        >
                          <div className="flex items-center justify-between">
                            <div>
                              <h4 className="font-medium text-gray-900">{cliente.nombre}</h4>
                              <p className="text-sm text-gray-600 flex items-center gap-1">
                                <Phone className="h-3 w-3" />
                                {cliente.telefono}
                              </p>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Cobros Results */}
                {filteredCobros && filteredCobros.length > 0 && (
                  <div>
                    <h3 className="text-sm font-medium text-gray-900 mb-3 flex items-center gap-2">
                      <DollarSign className="h-4 w-4" />
                      Cobros
                    </h3>
                    <div className="space-y-2">
                      {filteredCobros.map((cobro) => (
                        <div
                          key={cobro.id}
                          className="p-3 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors cursor-pointer"
                          onClick={() => handleContactClient(cobro.cliente.telefono)}
                        >
                          <div className="flex items-center justify-between">
                            <div>
                              <h4 className="font-medium text-gray-900">{cobro.cliente.nombre}</h4>
                              <p className="text-sm text-gray-600">{cobro.descripcion}</p>
                            </div>
                            <div className="text-right">
                              <p className="font-medium text-gray-900">
                                {formatMonto(cobro.monto)}
                              </p>
                              <p className="text-xs text-gray-500 capitalize">{cobro.estado}</p>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
