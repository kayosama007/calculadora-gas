import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import type { Pago, InsertPago } from "@shared/schema";

export function usePagos() {
  const query = useQuery<Pago[]>({
    queryKey: ["/api/pagos"],
  });

  const createPago = useMutation({
    mutationFn: async (data: InsertPago): Promise<Pago> => {
      const response = await apiRequest("POST", "/api/pagos", data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/pagos"] });
      queryClient.invalidateQueries({ queryKey: ["/api/cobros"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard"] });
      queryClient.invalidateQueries({ queryKey: ["/api/clientes"] });
    },
  });

  const deletePago = useMutation({
    mutationFn: async (id: number): Promise<void> => {
      await apiRequest("DELETE", `/api/pagos/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/pagos"] });
      queryClient.invalidateQueries({ queryKey: ["/api/cobros"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard"] });
      queryClient.invalidateQueries({ queryKey: ["/api/clientes"] });
    },
  });

  return {
    ...query,
    createPago,
    deletePago,
  };
}
