import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import type { Cobro, InsertCobro, CobroConCliente } from "@shared/schema";

export function useCobros() {
  const query = useQuery<CobroConCliente[]>({
    queryKey: ["/api/cobros"],
  });

  const cobrosPendientes = useQuery<CobroConCliente[]>({
    queryKey: ["/api/cobros/pendientes"],
  });

  const cobrosVencidos = useQuery<CobroConCliente[]>({
    queryKey: ["/api/cobros/vencidos"],
  });

  const createCobro = useMutation({
    mutationFn: async (data: InsertCobro): Promise<Cobro> => {
      const response = await apiRequest("POST", "/api/cobros", data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/cobros"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard"] });
      queryClient.invalidateQueries({ queryKey: ["/api/clientes"] });
    },
  });

  const updateCobro = useMutation({
    mutationFn: async ({ id, data }: { id: number; data: Partial<InsertCobro> }): Promise<Cobro> => {
      const response = await apiRequest("PUT", `/api/cobros/${id}`, data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/cobros"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard"] });
    },
  });

  const deleteCobro = useMutation({
    mutationFn: async (id: number): Promise<void> => {
      await apiRequest("DELETE", `/api/cobros/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/cobros"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard"] });
      queryClient.invalidateQueries({ queryKey: ["/api/clientes"] });
    },
  });

  return {
    ...query,
    cobrosPendientes,
    cobrosVencidos,
    createCobro,
    updateCobro,
    deleteCobro,
  };
}
