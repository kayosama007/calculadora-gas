import { useQuery, useMutation, QueryClient } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import type { Cliente, InsertCliente, ClienteConDeuda } from "@shared/schema";

export function useClientes() {
  const query = useQuery<ClienteConDeuda[]>({
    queryKey: ["/api/clientes/con-deuda"],
  });

  const createCliente = useMutation({
    mutationFn: async (data: InsertCliente): Promise<Cliente> => {
      const response = await apiRequest("POST", "/api/clientes", data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/clientes"] });
    },
  });

  const updateCliente = useMutation({
    mutationFn: async ({ id, data }: { id: number; data: Partial<InsertCliente> }): Promise<Cliente> => {
      const response = await apiRequest("PUT", `/api/clientes/${id}`, data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/clientes"] });
    },
  });

  const deleteCliente = useMutation({
    mutationFn: async (id: number): Promise<void> => {
      await apiRequest("DELETE", `/api/clientes/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/clientes"] });
    },
  });

  const searchClientes = useMutation({
    mutationFn: async (query: string): Promise<Cliente[]> => {
      const response = await apiRequest("GET", `/api/clientes/search/${encodeURIComponent(query)}`);
      return response.json();
    },
  });

  return {
    ...query,
    createCliente,
    updateCliente,
    deleteCliente,
    searchClientes,
  };
}
