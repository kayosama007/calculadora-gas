import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import Dashboard from "@/pages/dashboard";
import Login from "@/pages/login";
import Calculadora from "@/pages/calculadora";
import Tanques from "@/pages/tanques";
import Historial from "@/pages/historial";
import Perfil from "@/pages/perfil";
import Admin from "@/pages/admin";
import Pipas from "@/pages/pipas";
import NotFound from "@/pages/not-found";
import Header from "@/components/layout/header";
import BottomNavigation from "@/components/layout/bottom-navigation";
import FloatingActionButton from "@/components/layout/floating-action-button";
import { UserProvider } from "@/contexts/user-context";

function Router() {
  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      <main className="pb-20">
        <Switch>
          <Route path="/" component={Dashboard} />
          <Route path="/login" component={Login} />
          <Route path="/calculadora" component={Calculadora} />
          <Route path="/tanques" component={Tanques} />
          <Route path="/historial" component={Historial} />
          <Route path="/perfil" component={Perfil} />
          <Route path="/pipas" component={Pipas} />
          <Route path="/admin" component={Admin} />
          <Route component={NotFound} />
        </Switch>
      </main>
      <BottomNavigation />
      <FloatingActionButton />
    </div>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <UserProvider>
          <Toaster />
          <Router />
        </UserProvider>
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;