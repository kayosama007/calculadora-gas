import { useEffect, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { MapPin, Star, Plus, AlertCircle, Phone, Trash2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { useUser } from "@/contexts/user-context";
import type { ProveedorConEvaluaciones, InsertProveedor, InsertEvaluacion } from "@shared/schema";

export default function Pipas() {
  const { usuario } = useUser();
  const { toast } = useToast();
  const [proveedores, setProveedores] = useState<ProveedorConEvaluaciones[]>([]);
  const [proveedoresCercanos, setProveedoresCercanos] = useState<ProveedorConEvaluaciones[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [showNewProveedor, setShowNewProveedor] = useState(false);
  const [showEvaluar, setShowEvaluar] = useState(false);
  const [showCercanos, setShowCercanos] = useState(false);
  const [selectedProveedor, setSelectedProveedor] = useState<ProveedorConEvaluaciones | null>(null);
  const [nuevoProveedor, setNuevoProveedor] = useState({ 
    nombre: "", 
    telefono: "", 
    zona: "", 
    ciudad: "",
    codigoPostal: "",
    direccion: "",
    barrio: "",
    referencia: "",
    horarioAtencion: "",
    descripcion: ""
  });
  const [evaluacion, setEvaluacion] = useState({ calificacion: 5, comentario: "" });

  useEffect(() => {
    fetchProveedores();
  }, []);

  const fetchProveedores = async () => {
    setIsLoading(true);
    try {
      const response = await apiRequest("GET", "/api/proveedores");
      const data = await response.json();
      setProveedores(data);
      
      // Filtrar proveedores cercanos por ubicación del usuario
      if (usuario?.codigoPostal || usuario?.ciudad || usuario?.zona) {
        try {
          const params = new URLSearchParams();
          if (usuario.codigoPostal) params.append("codigoPostal", usuario.codigoPostal);
          if (usuario.ciudad) params.append("ciudad", usuario.ciudad);
          if (usuario.zona) params.append("zona", usuario.zona);
          const cercResponse = await apiRequest("GET", `/api/proveedores/cercanos?${params}`);
          const cercanos = await cercResponse.json();
          setProveedoresCercanos(cercanos);
        } catch (err) {
          console.error("Error al obtener proveedores cercanos:", err);
          setProveedoresCercanos([]);
        }
      }
    } catch (error) {
      toast({ title: "Error", description: "No se pudieron cargar los proveedores", variant: "destructive" });
    } finally {
      setIsLoading(false);
    }
  };

  const handleAddProveedor = async () => {
    if (!nuevoProveedor.nombre || !nuevoProveedor.telefono) {
      toast({ title: "Error", description: "Nombre y teléfono son requeridos", variant: "destructive" });
      return;
    }

    try {
      const data: InsertProveedor = {
        usuarioId: usuario!.id,
        ...nuevoProveedor,
      };
      const response = await apiRequest("POST", "/api/proveedores", data);
      await response.json();
      toast({ title: "Éxito", description: "Proveedor registrado correctamente" });
      setShowNewProveedor(false);
      setNuevoProveedor({ nombre: "", telefono: "", zona: "", ciudad: "", codigoPostal: "", direccion: "", barrio: "", referencia: "", horarioAtencion: "", descripcion: "" });
      fetchProveedores();
    } catch (error) {
      toast({ title: "Error", description: "No se pudo registrar el proveedor", variant: "destructive" });
    }
  };

  const handleEvaluar = async () => {
    if (!selectedProveedor) return;

    try {
      const data: InsertEvaluacion = {
        proveedorId: selectedProveedor.id,
        usuarioId: usuario!.id,
        calificacion: evaluacion.calificacion,
        comentario: evaluacion.comentario || null,
      };
      const response = await apiRequest("POST", "/api/evaluaciones", data);
      await response.json();
      toast({ title: "Éxito", description: "Evaluación enviada correctamente" });
      setShowEvaluar(false);
      setEvaluacion({ calificacion: 5, comentario: "" });
      fetchProveedores();
    } catch (error) {
      toast({ title: "Error", description: "No se pudo enviar la evaluación", variant: "destructive" });
    }
  };

  const handleEliminarProveedor = async (proveedorId: number) => {
    if (!confirm("¿Deseas eliminar este proveedor?")) return;

    try {
      await apiRequest("DELETE", `/api/proveedores/${proveedorId}`);
      toast({ title: "Éxito", description: "Proveedor eliminado correctamente" });
      fetchProveedores();
    } catch (error) {
      toast({ title: "Error", description: "No se pudo eliminar el proveedor", variant: "destructive" });
    }
  };

  return (
    <div className="max-w-6xl mx-auto px-4 py-6 space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Pipas Cercanas</h1>
          <p className="text-gray-600">Encuentra y califica proveedores de gas en tu zona</p>
        </div>
        <Button onClick={() => setShowNewProveedor(true)} className="gap-2">
          <Plus className="h-4 w-4" />
          Registrar Pipa
        </Button>
      </div>

      {/* Mensaje explicativo */}
      <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 space-y-2">
        <h3 className="font-semibold text-blue-900">📍 ¿Por qué registrar pipas?</h3>
        <p className="text-sm text-blue-800">
          El registro de pipas ayuda a usuarios como tú a encontrar nuevas opciones de proveedores de gas. Según tu ubicación y la ubicación que otros usuarios registren, verás las pipas más cercanas a ti. Comparte los proveedores que conoces para ayudar a tu comunidad.
        </p>
      </div>

      {/* Botón Pipas cercas de ti */}
      {usuario?.zona && proveedoresCercanos.length > 0 && (
        <Button 
          onClick={() => setShowCercanos(!showCercanos)} 
          variant="default" 
          className="w-full gap-2 text-lg py-6"
          data-testid="button-nearby-providers"
        >
          <MapPin className="h-5 w-5" />
          Pipas Cercas de Ti ({proveedoresCercanos.length})
        </Button>
      )}

      {showCercanos && usuario?.zona && (
        <div className="space-y-4">
          <div className="bg-green-50 border border-green-200 rounded p-3">
            <p className="text-sm text-green-800">
              📌 Mostrando pipas en tu zona: <strong>{usuario.zona}</strong>
            </p>
          </div>
          {proveedoresCercanos.length === 0 ? (
            <Card>
              <CardContent className="py-8 text-center">
                <AlertCircle className="h-8 w-8 text-gray-400 mx-auto mb-2" />
                <p className="text-gray-500">No hay pipas registradas en tu zona aún</p>
              </CardContent>
            </Card>
          ) : (
            <div className="grid gap-4">
              {proveedoresCercanos.map((prov) => (
                <Card key={prov.id} className={prov.confiable ? "border-green-500 border-2" : ""}>
                  <CardHeader>
                    <div className="flex justify-between items-start">
                      <div className="flex-1">
                        <CardTitle className="flex items-center gap-2">
                          {prov.nombre}
                          {prov.confiable && <span className="bg-green-100 text-green-800 text-xs px-2 py-1 rounded">✓ Confiable</span>}
                        </CardTitle>
                        <div className="text-sm text-gray-600 mt-1 space-y-1">
                          <p>📞 {prov.telefono}</p>
                          {prov.zona && <p><MapPin className="h-3 w-3 inline" /> {prov.zona}{prov.ciudad ? `, ${prov.ciudad}` : ""}</p>}
                        </div>
                      </div>
                      {prov.totalEvaluaciones > 0 && (
                        <div className="text-right">
                          <div className="flex items-center gap-1 text-yellow-500">
                            <Star className="h-4 w-4 fill-current" />
                            <span className="font-bold">{prov.promedioCalificacion}</span>
                          </div>
                          <p className="text-xs text-gray-500">{prov.totalEvaluaciones} evaluaciones</p>
                        </div>
                      )}
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2">
                      <Button onClick={() => { setSelectedProveedor(prov); setShowEvaluar(true); }} variant="outline" className="w-full">
                        Calificar
                      </Button>
                      <div className="flex gap-2">
                        <a href={`tel:${prov.telefono}`} className="flex-1">
                          <Button variant="default" className="w-full gap-2" data-testid={`button-call-${prov.id}`}>
                            <Phone className="h-4 w-4" />
                            Llamar
                          </Button>
                        </a>
                        <Button
                          variant="destructive"
                          size="sm"
                          onClick={() => handleEliminarProveedor(prov.id)}
                          data-testid={`button-delete-provider-${prov.id}`}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </div>
      )}

      {isLoading ? (
        <Card>
          <CardContent className="py-8 text-center text-gray-500">Cargando proveedores...</CardContent>
        </Card>
      ) : !showCercanos && proveedores.length === 0 ? (
        <Card>
          <CardContent className="py-8 text-center">
            <AlertCircle className="h-8 w-8 text-gray-400 mx-auto mb-2" />
            <p className="text-gray-500">No hay proveedores registrados aún</p>
          </CardContent>
        </Card>
      ) : !showCercanos && (
        <div className="grid gap-4">
          {proveedores.map((prov) => (
            <Card key={prov.id} className={prov.confiable ? "border-green-500 border-2" : ""}>
              <CardHeader>
                <div className="flex justify-between items-start">
                  <div className="flex-1">
                    <CardTitle className="flex items-center gap-2 text-base">
                      {prov.nombre}
                      {prov.confiable && <span className="bg-green-100 text-green-800 text-xs px-2 py-1 rounded">✓ Confiable</span>}
                      {(prov.estrellas ?? 0) > 0 && <span className="text-yellow-500 text-xs">{'⭐'.repeat(prov.estrellas)}</span>}
                    </CardTitle>
                    <div className="text-xs text-gray-600 mt-2 space-y-1">
                      <p className="flex items-center gap-1"><span>📞</span> {prov.telefono}</p>
                      {prov.zona && <p className="flex items-center gap-1"><MapPin className="h-3 w-3" /> <strong>{prov.zona}</strong>{prov.ciudad ? `, ${prov.ciudad}` : ""}</p>}
                      {prov.barrio && <p className="flex items-center gap-1"><span>🏘️</span> {prov.barrio}</p>}
                      {prov.direccion && <p className="flex items-center gap-1"><span>📍</span> {prov.direccion}</p>}
                      {prov.referencia && <p className="flex items-center gap-1"><span>🗺️</span> {prov.referencia}</p>}
                      {prov.horarioAtencion && <p className="flex items-center gap-1"><span>🕐</span> {prov.horarioAtencion}</p>}
                      {prov.descripcion && <p className="text-gray-500 italic">"{prov.descripcion}"</p>}
                    </div>
                  </div>
                  {prov.totalEvaluaciones > 0 && (
                    <div className="text-right">
                      <div className="flex items-center gap-1 text-yellow-500">
                        <Star className="h-4 w-4 fill-current" />
                        <span className="font-bold">{prov.promedioCalificacion}</span>
                      </div>
                      <p className="text-xs text-gray-500">{prov.totalEvaluaciones} evaluaciones</p>
                    </div>
                  )}
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <Button onClick={() => { setSelectedProveedor(prov); setShowEvaluar(true); }} variant="outline" className="w-full">
                    Calificar
                  </Button>
                  <div className="flex gap-2">
                    <a href={`tel:${prov.telefono}`} className="flex-1">
                      <Button variant="default" className="w-full gap-2" data-testid={`button-call-${prov.id}`}>
                        <Phone className="h-4 w-4" />
                        Llamar
                      </Button>
                    </a>
                    <Button
                      variant="destructive"
                      size="sm"
                      onClick={() => handleEliminarProveedor(prov.id)}
                      data-testid={`button-delete-provider-${prov.id}`}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {/* Modal agregar proveedor */}
      <Dialog open={showNewProveedor} onOpenChange={setShowNewProveedor}>
        <DialogContent className="max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Registrar Nueva Pipa</DialogTitle>
            <DialogDescription>Comparte información completa para ayudar a otros usuarios</DialogDescription>
          </DialogHeader>
          <div className="space-y-3 py-4">
            <div>
              <label className="text-xs font-semibold text-gray-700 block mb-1">Nombre del proveedor *</label>
              <input type="text" placeholder="Ej: Pipas Don Juan" value={nuevoProveedor.nombre} onChange={(e) => setNuevoProveedor({ ...nuevoProveedor, nombre: e.target.value })} className="w-full px-3 py-2 border rounded text-sm" />
            </div>
            <div>
              <label className="text-xs font-semibold text-gray-700 block mb-1">Teléfono *</label>
              <input type="text" placeholder="Ej: +52 123 456 7890" value={nuevoProveedor.telefono} onChange={(e) => setNuevoProveedor({ ...nuevoProveedor, telefono: e.target.value })} className="w-full px-3 py-2 border rounded text-sm" />
            </div>
            <div>
              <label className="text-xs font-semibold text-gray-700 block mb-1">Zona/Región *</label>
              <input type="text" placeholder="Ej: Sur, Centro, Norte" value={nuevoProveedor.zona} onChange={(e) => setNuevoProveedor({ ...nuevoProveedor, zona: e.target.value })} className="w-full px-3 py-2 border rounded text-sm" />
            </div>
            <div>
              <label className="text-xs font-semibold text-gray-700 block mb-1">Ciudad</label>
              <input type="text" placeholder="Ej: Ciudad de México" value={nuevoProveedor.ciudad} onChange={(e) => setNuevoProveedor({ ...nuevoProveedor, ciudad: e.target.value })} className="w-full px-3 py-2 border rounded text-sm" />
            </div>
            <div>
              <label className="text-xs font-semibold text-gray-700 block mb-1">Barrio/Colonia</label>
              <input type="text" placeholder="Ej: La Roma, Condesa" value={nuevoProveedor.barrio} onChange={(e) => setNuevoProveedor({ ...nuevoProveedor, barrio: e.target.value })} className="w-full px-3 py-2 border rounded text-sm" />
            </div>
            <div>
              <label className="text-xs font-semibold text-gray-700 block mb-1">Dirección completa</label>
              <input type="text" placeholder="Ej: Avenida Principal #123" value={nuevoProveedor.direccion} onChange={(e) => setNuevoProveedor({ ...nuevoProveedor, direccion: e.target.value })} className="w-full px-3 py-2 border rounded text-sm" />
            </div>
            <div>
              <label className="text-xs font-semibold text-gray-700 block mb-1">Referencia de ubicación</label>
              <input type="text" placeholder="Ej: Cerca del parque, esquina con tienda" value={nuevoProveedor.referencia} onChange={(e) => setNuevoProveedor({ ...nuevoProveedor, referencia: e.target.value })} className="w-full px-3 py-2 border rounded text-sm" />
            </div>
            <div>
              <label className="text-xs font-semibold text-gray-700 block mb-1">Horario de atención</label>
              <input type="text" placeholder="Ej: 7am - 8pm, Cerrado domingos" value={nuevoProveedor.horarioAtencion} onChange={(e) => setNuevoProveedor({ ...nuevoProveedor, horarioAtencion: e.target.value })} className="w-full px-3 py-2 border rounded text-sm" />
            </div>
            <div>
              <label className="text-xs font-semibold text-gray-700 block mb-1">Descripción adicional</label>
              <textarea placeholder="Ej: Reparten a domicilio, precios especiales..." value={nuevoProveedor.descripcion} onChange={(e) => setNuevoProveedor({ ...nuevoProveedor, descripcion: e.target.value })} className="w-full px-3 py-2 border rounded text-sm" rows={2} />
            </div>
            <Button onClick={handleAddProveedor} className="w-full">Registrar Pipa</Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Modal evaluar */}
      <Dialog open={showEvaluar} onOpenChange={setShowEvaluar}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Calificar {selectedProveedor?.nombre}</DialogTitle>
            <DialogDescription>Comparte tu experiencia con otros usuarios</DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div>
              <label className="block text-sm font-medium mb-2">Calificación (1-5 estrellas)</label>
              <div className="flex gap-2">
                {[1, 2, 3, 4, 5].map((star) => (
                  <button key={star} onClick={() => setEvaluacion({ ...evaluacion, calificacion: star })} className={`text-2xl ${evaluacion.calificacion >= star ? "text-yellow-500" : "text-gray-300"}`}>
                    ★
                  </button>
                ))}
              </div>
            </div>
            <div>
              <label className="block text-sm font-medium mb-2">Comentario (opcional)</label>
              <textarea placeholder="Comparte tu opinión..." value={evaluacion.comentario} onChange={(e) => setEvaluacion({ ...evaluacion, comentario: e.target.value })} className="w-full px-3 py-2 border rounded text-sm" rows={3} />
            </div>
            <Button onClick={handleEvaluar} className="w-full">Enviar Evaluación</Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
