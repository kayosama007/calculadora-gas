import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { useToast } from "@/hooks/use-toast";
import { useUser } from "@/contexts/user-context";
import { apiRequest } from "@/lib/queryClient";
import { useLocation } from "wouter";
import { Fuel, User, Mail, Zap } from "lucide-react";
import TermsModal from "@/components/modals/terms-modal";
import type { Usuario, InsertUsuario } from "@shared/schema";

const loginSchema = z.object({
  email: z.string().email("Email inválido"),
});

const registerSchema = z.object({
  nombre: z.string().min(1, "El nombre es requerido"),
  email: z.string().email("Email inválido"),
  telefono: z.string().optional(),
  zona: z.string().optional(),
  ciudad: z.string().optional(),
  calle: z.string().optional(),
  numero: z.string().optional(),
  departamento: z.string().optional(),
  codigoPostal: z.string().optional(),
  aceptoTerminos: z.boolean().refine(val => val === true, "Debes aceptar los términos y condiciones"),
});

export default function Login() {
  const [isRegistering, setIsRegistering] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [showTerms, setShowTerms] = useState(false);
  const { setUsuario } = useUser();
  const { toast } = useToast();
  const [, setLocation] = useLocation();

  const loginForm = useForm({
    resolver: zodResolver(loginSchema),
    defaultValues: { email: "" },
  });

  const registerForm = useForm({
    resolver: zodResolver(registerSchema),
    defaultValues: { 
      nombre: "", 
      email: "", 
      telefono: "", 
      zona: "",
      ciudad: "",
      calle: "",
      numero: "",
      departamento: "",
      codigoPostal: "",
      aceptoTerminos: false 
    },
  });

  const handleLogin = async (data: { email: string }) => {
    setIsLoading(true);
    try {
      const response = await apiRequest("GET", `/api/usuarios/email/${encodeURIComponent(data.email)}`);
      const usuario: Usuario = await response.json();
      
      setUsuario(usuario);
      toast({
        title: "Bienvenido",
        description: `Hola ${usuario.nombre}, has iniciado sesión correctamente.`,
      });
      setLocation("/");
    } catch (error) {
      toast({
        title: "Usuario no encontrado",
        description: "No existe una cuenta con este email. ¿Deseas registrarte?",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleAcceptTerms = () => {
    registerForm.setValue("aceptoTerminos", true);
    setShowTerms(false);
  };

  const handleRejectTerms = () => {
    setShowTerms(false);
    toast({
      title: "Términos rechazados",
      description: "Debes aceptar los términos para continuar",
      variant: "destructive",
    });
  };

  const handleRegister = async (data: InsertUsuario) => {
    setIsLoading(true);
    try {
      const response = await apiRequest("POST", "/api/usuarios", data);
      const usuario: Usuario = await response.json();
      
      setUsuario(usuario);
      toast({
        title: "Registro exitoso",
        description: `Bienvenido ${usuario.nombre}, tu cuenta ha sido creada.`,
      });
      setLocation("/");
    } catch (error: any) {
      let errorMessage = "No se pudo crear la cuenta.";
      
      // Si el error viene del servidor con un mensaje específico
      if (error.response && error.response.message) {
        errorMessage = error.response.message;
        
        // Si es error de email duplicado, sugerir usar login
        if (error.response.message.includes("Ya existe una cuenta")) {
          errorMessage += ". Usa el botón 'Ingresar' si ya tienes cuenta.";
          
          // Automáticamente cambiar a la vista de login
          setTimeout(() => {
            setIsRegistering(false);
          }, 3000);
        }
      }
      
      toast({
        title: "Error en el registro",
        description: errorMessage,
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4 bg-gradient-to-br from-blue-50 to-indigo-100">
      <Card className="w-full max-w-md">
        <CardHeader className="text-center">
          <div className="w-20 h-20 bg-gradient-to-br from-blue-500 to-blue-600 rounded-full flex items-center justify-center mx-auto mb-4 shadow-lg">
            <div className="relative">
              <Fuel className="h-10 w-10 text-white" />
              <Zap className="h-5 w-5 text-yellow-300 absolute -bottom-1 -right-1" />
            </div>
          </div>
          <CardTitle className="text-2xl font-bold text-gray-900">
            calculadoradegas
          </CardTitle>
          <p className="text-gray-600">
            {isRegistering ? "Crear cuenta nueva" : "Calculadora de Gas Estacionario"}
          </p>
        </CardHeader>

        <CardContent>
          {!isRegistering ? (
            <div className="space-y-4">
              <Form {...loginForm}>
                <form onSubmit={loginForm.handleSubmit(handleLogin)} className="space-y-4">
                  <FormField
                    control={loginForm.control}
                    name="email"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Email</FormLabel>
                        <FormControl>
                          <div className="relative">
                            <Mail className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                            <Input
                              placeholder="tu@email.com"
                              className="pl-10"
                              {...field}
                            />
                          </div>
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <Button
                    type="submit"
                    className="w-full bg-primary hover:bg-primary/90"
                    disabled={isLoading}
                  >
                    {isLoading ? "Ingresando..." : "Ingresar"}
                  </Button>

                  <div className="text-center">
                    <Button
                      type="button"
                      variant="ghost"
                      onClick={() => setIsRegistering(true)}
                      className="text-primary hover:text-primary/80"
                    >
                      ¿No tienes cuenta? Regístrate
                    </Button>
                  </div>
                </form>
              </Form>
            </div>
          ) : (
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Nombre completo</label>
                <div className="relative">
                  <User className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                  <input
                    type="text"
                    placeholder="Tu nombre"
                    className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-primary focus:border-transparent"
                    value={registerForm.watch("nombre") || ""}
                    onChange={(e) => registerForm.setValue("nombre", e.target.value)}
                  />
                </div>
                {registerForm.formState.errors.nombre && (
                  <p className="text-red-500 text-xs mt-1">{registerForm.formState.errors.nombre.message}</p>
                )}
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Email</label>
                <div className="relative">
                  <Mail className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                  <input
                    type="email"
                    placeholder="tu@email.com"
                    className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-primary focus:border-transparent"
                    value={registerForm.watch("email") || ""}
                    onChange={(e) => registerForm.setValue("email", e.target.value)}
                  />
                </div>
                {registerForm.formState.errors.email && (
                  <p className="text-red-500 text-xs mt-1">{registerForm.formState.errors.email.message}</p>
                )}
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Teléfono (opcional)</label>
                <input
                  type="text"
                  placeholder="+54 11 1234-5678"
                  className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-primary focus:border-transparent"
                  value={registerForm.watch("telefono") || ""}
                  onChange={(e) => registerForm.setValue("telefono", e.target.value)}
                />
              </div>

              <div className="border-t pt-4 mt-4">
                <h3 className="text-sm font-semibold text-gray-900 mb-3">Datos de domicilio (opcional)</h3>
              
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Zona/Región</label>
                  <input
                    type="text"
                    placeholder="Ej: Sur, Centro, Norte"
                    className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-primary focus:border-transparent"
                    value={registerForm.watch("zona") || ""}
                    onChange={(e) => registerForm.setValue("zona", e.target.value)}
                  />
                </div>

                <div className="mt-3">
                  <label className="block text-sm font-medium text-gray-700 mb-2">Ciudad</label>
                  <input
                    type="text"
                    placeholder="Tu ciudad"
                    className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-primary focus:border-transparent"
                    value={registerForm.watch("ciudad") || ""}
                    onChange={(e) => registerForm.setValue("ciudad", e.target.value)}
                  />
                </div>

                <div className="mt-3">
                  <label className="block text-sm font-medium text-gray-700 mb-2">Calle</label>
                  <input
                    type="text"
                    placeholder="Ej: Avenida Principal"
                    className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-primary focus:border-transparent"
                    value={registerForm.watch("calle") || ""}
                    onChange={(e) => registerForm.setValue("calle", e.target.value)}
                  />
                </div>

                <div className="grid grid-cols-2 gap-2 mt-3">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Número</label>
                    <input
                      type="text"
                      placeholder="123"
                      className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-primary focus:border-transparent"
                      value={registerForm.watch("numero") || ""}
                      onChange={(e) => registerForm.setValue("numero", e.target.value)}
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Depto/Apt</label>
                    <input
                      type="text"
                      placeholder="101"
                      className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-primary focus:border-transparent"
                      value={registerForm.watch("departamento") || ""}
                      onChange={(e) => registerForm.setValue("departamento", e.target.value)}
                    />
                  </div>
                </div>

                <div className="mt-3">
                  <label className="block text-sm font-medium text-gray-700 mb-2">Código Postal</label>
                  <input
                    type="text"
                    placeholder="CP: 28001"
                    className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-primary focus:border-transparent"
                    value={registerForm.watch("codigoPostal") || ""}
                    onChange={(e) => registerForm.setValue("codigoPostal", e.target.value)}
                  />
                </div>
              </div>

              <div className="flex items-start space-x-3 bg-gray-50 p-4 rounded-lg border border-gray-200 mt-4">
                <input
                  type="checkbox"
                  id="terms"
                  checked={registerForm.watch("aceptoTerminos") || false}
                  onChange={(e) => registerForm.setValue("aceptoTerminos", e.target.checked)}
                  className="mt-1 h-4 w-4 rounded border-gray-300 text-primary focus:ring-primary cursor-pointer"
                  data-testid="checkbox-accept-terms"
                />
                <label htmlFor="terms" className="text-sm text-gray-700 cursor-pointer flex-1">
                  Acepto los{" "}
                  <Button
                    type="button"
                    variant="link"
                    className="p-0 h-auto text-primary hover:underline"
                    onClick={() => setShowTerms(true)}
                    data-testid="button-read-terms"
                  >
                    términos y condiciones
                  </Button>
                </label>
              </div>
              {registerForm.formState.errors.aceptoTerminos && (
                <p className="text-red-500 text-xs mt-2">{registerForm.formState.errors.aceptoTerminos.message}</p>
              )}

              <Button
                type="button"
                className="w-full bg-primary hover:bg-primary/90 mt-4"
                disabled={isLoading}
                onClick={() => {
                  const data = registerForm.getValues();
                  if (data.nombre && data.email && data.aceptoTerminos) {
                    handleRegister(data);
                  } else {
                    if (!data.nombre || !data.email) {
                      toast({
                        title: "Campos requeridos",
                        description: "Por favor completa al menos el nombre y email.",
                        variant: "destructive",
                      });
                    } else if (!data.aceptoTerminos) {
                      toast({
                        title: "Términos no aceptados",
                        description: "Debes aceptar los términos y condiciones para continuar.",
                        variant: "destructive",
                      });
                    }
                  }
                }}
                data-testid="button-create-account"
              >
                {isLoading ? "Creando cuenta..." : "Crear cuenta"}
              </Button>

              <div className="text-center">
                <Button
                  type="button"
                  variant="ghost"
                  onClick={() => setIsRegistering(false)}
                  className="text-primary hover:text-primary/80"
                >
                  ¿Ya tienes cuenta? Ingresar
                </Button>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Modal de Términos */}
      <TermsModal
        open={showTerms}
        onAccept={handleAcceptTerms}
        onReject={handleRejectTerms}
      />
    </div>
  );
}