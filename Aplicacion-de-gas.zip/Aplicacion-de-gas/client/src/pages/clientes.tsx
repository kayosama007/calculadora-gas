import { useState } from "react";
import { useClientes } from "@/hooks/use-clientes";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Skeleton } from "@/components/ui/skeleton";
import ClienteForm from "@/components/forms/cliente-form";
import { Search, Plus, Phone, MapPin } from "lucide-react";

export default function Clientes() {
  const [searchQuery, setSearchQuery] = useState("");
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const { data: clientes, isLoading, searchClientes } = useClientes();

  const handleSearch = (query: string) => {
    setSearchQuery(query);
    if (query.trim()) {
      searchClientes.mutate(query);
    }
  };

  const displayedClientes = searchQuery.trim() ? searchClientes.data : clientes;

  const formatDeuda = (deuda: string) => {
    const amount = parseFloat(deuda);
    return new Intl.NumberFormat('es-AR', {
      style: 'currency',
      currency: 'ARS'
    }).format(amount);
  };

  const getInitials = (nombre: string) => {
    return nombre
      .split(' ')
      .map(word => word[0])
      .join('')
      .toUpperCase()
      .slice(0, 2);
  };

  if (isLoading) {
    return (
      <div className="px-4 py-6 space-y-4">
        <Skeleton className="h-10 w-full" />
        {Array.from({ length: 5 }).map((_, i) => (
          <Skeleton key={i} className="h-20 w-full" />
        ))}
      </div>
    );
  }

  return (
    <div className="px-4 py-6 space-y-6">
      {/* Search and Add */}
      <div className="flex gap-3">
        <div className="flex-1 relative">
          <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
          <Input
            placeholder="Buscar clientes..."
            value={searchQuery}
            onChange={(e) => handleSearch(e.target.value)}
            className="pl-10"
          />
        </div>
        <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
          <DialogTrigger asChild>
            <Button className="bg-primary text-white hover:bg-primary/90">
              <Plus className="h-4 w-4 mr-2" />
              Nuevo
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Nuevo Cliente</DialogTitle>
            </DialogHeader>
            <ClienteForm onSuccess={() => setIsCreateDialogOpen(false)} />
          </DialogContent>
        </Dialog>
      </div>

      {/* Clientes List */}
      <div className="space-y-3">
        {displayedClientes?.map((cliente) => (
          <Card key={cliente.id} className="bg-white hover:bg-gray-50 transition-colors">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center">
                    <span className="text-sm font-semibold text-primary">
                      {getInitials(cliente.nombre)}
                    </span>
                  </div>
                  <div>
                    <h3 className="font-medium text-gray-900">{cliente.nombre}</h3>
                    <div className="flex items-center gap-4 text-xs text-gray-500 mt-1">
                      <span className="flex items-center gap-1">
                        <Phone className="h-3 w-3" />
                        {cliente.telefono}
                      </span>
                      {cliente.direccion && (
                        <span className="flex items-center gap-1">
                          <MapPin className="h-3 w-3" />
                          {cliente.direccion}
                        </span>
                      )}
                    </div>
                  </div>
                </div>
                <div className="text-right">
                  <p className="text-sm font-medium text-gray-900">
                    {formatDeuda(cliente.deudaTotal)}
                  </p>
                  <p className="text-xs text-gray-500">
                    {cliente.cobrosActivos} cobros activos
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}

        {displayedClientes?.length === 0 && (
          <Card>
            <CardContent className="p-8 text-center">
              <p className="text-gray-500">
                {searchQuery ? "No se encontraron clientes" : "No hay clientes registrados"}
              </p>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}
