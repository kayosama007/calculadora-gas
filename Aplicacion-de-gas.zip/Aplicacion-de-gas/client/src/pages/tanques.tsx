import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Fuel, Plus, Settings, Loader2, HelpCircle } from "lucide-react";
import { useUser } from "@/contexts/user-context";
import { useLocation } from "wouter";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { insertTanqueSchema, type Tanque } from "@shared/schema";
import { queryClient } from "@/lib/queryClient";
import TankCapacityHelpModal from "@/components/modals/tank-capacity-help-modal";

type TanqueForm = {
  marca: string;
  capacidad: string;
};

export default function Tanques() {
  const { usuario, isAuthenticated } = useUser();
  const [, setLocation] = useLocation();
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const [showCapacityHelp, setShowCapacityHelp] = useState(false);
  const { toast } = useToast();

  if (!isAuthenticated) {
    setLocation("/login");
    return null;
  }

  // Fetch tanques del usuario
  const { data: tanques = [], isLoading, error } = useQuery({
    queryKey: ["/api/tanques/usuario", usuario?.id],
    queryFn: async () => {
      if (!usuario?.id) return [];
      const response = await apiRequest("GET", `/api/tanques/usuario/${usuario.id}`);
      return response.json();
    },
    enabled: !!usuario?.id,
  });

  // Form setup
  const form = useForm<TanqueForm>({
    resolver: zodResolver(
      insertTanqueSchema.pick({
        marca: true,
        capacidad: true,
      })
    ),
    defaultValues: {
      marca: "",
      capacidad: "",
    },
  });

  // Mutation para crear tanque
  const createTanqueMutation = useMutation({
    mutationFn: async (data: TanqueForm) => {
      const response = await apiRequest("POST", "/api/tanques", {
        usuarioId: usuario?.id,
        marca: data.marca,
        capacidad: data.capacidad,
      });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/tanques/usuario", usuario?.id] });
      setIsCreateDialogOpen(false);
      form.reset();
      toast({
        title: "Tanque creado",
        description: "Tu tanque ha sido registrado exitosamente.",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error al crear tanque",
        description: error.message || "No se pudo crear el tanque.",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: TanqueForm) => {
    createTanqueMutation.mutate(data);
  };

  const getGaugeColor = (percentage: number) => {
    if (percentage <= 25) return "bg-red-500";
    if (percentage <= 50) return "bg-yellow-500";
    return "bg-green-500";
  };

  return (
    <div className="px-4 py-6 space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-semibold text-gray-900">Mis Tanques</h1>
          <p className="text-gray-600">Gestiona tus tanques de gas registrados</p>
        </div>
        <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
          <DialogTrigger asChild>
            <Button className="bg-primary text-white hover:bg-primary/90" data-testid="button-add-tank">
              <Plus className="h-4 w-4 mr-2" />
              Agregar Tanque
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Agregar Nuevo Tanque</DialogTitle>
            </DialogHeader>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                <FormField
                  control={form.control}
                  name="marca"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Marca del Tanque</FormLabel>
                      <FormControl>
                        <Input 
                          placeholder="Ej: YPF, Shell, Metrogas" 
                          data-testid="input-tank-brand"
                          {...field} 
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="capacidad"
                  render={({ field }) => (
                    <FormItem>
                      <div className="flex items-center justify-between">
                        <FormLabel>Capacidad (litros)</FormLabel>
                        <Button
                          type="button"
                          variant="ghost"
                          size="sm"
                          onClick={() => setShowCapacityHelp(true)}
                          data-testid="button-help-capacity"
                          className="text-primary hover:text-primary/80 -mr-2"
                        >
                          <HelpCircle className="h-4 w-4 mr-1" />
                          ¿Cómo encuentro esto?
                        </Button>
                      </div>
                      <FormControl>
                        <Input 
                          placeholder="Ej: 45, 60, 90" 
                          data-testid="input-tank-capacity"
                          {...field} 
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <Button 
                  type="submit" 
                  className="w-full"
                  disabled={createTanqueMutation.isPending}
                  data-testid="button-submit-tank"
                >
                  {createTanqueMutation.isPending && (
                    <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  )}
                  {createTanqueMutation.isPending ? "Creando..." : "Crear Tanque"}
                </Button>
              </form>
            </Form>
          </DialogContent>
        </Dialog>
      </div>

      {/* Tanques List */}
      <div className="space-y-4">
        {isLoading ? (
          <Card>
            <CardContent className="p-8 text-center">
              <Loader2 className="h-8 w-8 text-primary mx-auto mb-4 animate-spin" />
              <p className="text-gray-500">Cargando tanques...</p>
            </CardContent>
          </Card>
        ) : error ? (
          <Card>
            <CardContent className="p-8 text-center">
              <p className="text-red-500 mb-4">Error al cargar tanques</p>
              <Button onClick={() => window.location.reload()}>Reintentar</Button>
            </CardContent>
          </Card>
        ) : tanques.length === 0 ? (
          <Card>
            <CardContent className="p-8 text-center">
              <Fuel className="h-12 w-12 text-gray-300 mx-auto mb-4" />
              <p className="text-gray-500 mb-4">No tienes tanques registrados</p>
              <Button onClick={() => setIsCreateDialogOpen(true)} data-testid="button-add-first-tank">
                <Plus className="h-4 w-4 mr-2" />
                Agregar tu primer tanque
              </Button>
            </CardContent>
          </Card>
        ) : (
          tanques.map((tanque: Tanque) => (
            <Card key={tanque.id} className="bg-white hover:shadow-md transition-shadow" data-testid={`card-tank-${tanque.id}`}>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-4">
                    <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center">
                      <Fuel className="h-6 w-6 text-primary" />
                    </div>
                    <div>
                      <h3 className="font-semibold text-gray-900" data-testid={`text-tank-brand-${tanque.id}`}>{tanque.marca}</h3>
                      <p className="text-sm text-gray-600">Capacidad: {tanque.capacidad}L</p>
                    </div>
                  </div>
                  
                  <div className="text-right">
                    <Button
                      variant="ghost"
                      size="sm"
                      className="text-primary hover:text-primary/80"
                      data-testid={`button-edit-tank-${tanque.id}`}
                    >
                      <Settings className="h-4 w-4 mr-1" />
                      Editar
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))
        )}
      </div>

      {/* Modal de ayuda para capacidad */}
      <TankCapacityHelpModal 
        open={showCapacityHelp} 
        onClose={() => setShowCapacityHelp(false)} 
      />

      {/* Quick Action */}
      <Card className="bg-gradient-to-r from-primary to-blue-600 text-white">
        <CardContent className="p-6">
          <div className="text-center">
            <h3 className="text-lg font-semibold mb-2">¿Listo para cargar gas?</h3>
            <p className="text-blue-100 mb-4">
              Usa la calculadora para saber cuánto pagarás
            </p>
            <Button 
              variant="secondary" 
              onClick={() => setLocation("/calculadora")}
              className="bg-white text-blue-600 hover:bg-blue-50"
              data-testid="button-go-calculator"
            >
              Ir a la Calculadora
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
