import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { User, Mail, Phone, LogOut, Edit, Save, X, MapPin } from "lucide-react";
import { useUser } from "@/contexts/user-context";
import { useLocation } from "wouter";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import PipasInfoModal from "@/components/modals/pipas-info-modal";

const perfilSchema = z.object({
  nombre: z.string().min(2, "El nombre debe tener al menos 2 caracteres"),
  email: z.string().email("Ingresa un email válido"),
  telefono: z.string().optional(),
  zona: z.string().optional(),
  ciudad: z.string().optional(),
  calle: z.string().optional(),
  numero: z.string().optional(),
  departamento: z.string().optional(),
  codigoPostal: z.string().optional(),
});

type PerfilForm = z.infer<typeof perfilSchema>;

export default function Perfil() {
  const { usuario, setUsuario, isAuthenticated, logout } = useUser();
  const [, setLocation] = useLocation();
  const [isEditing, setIsEditing] = useState(false);
  const [isEmailDialogOpen, setIsEmailDialogOpen] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [showPipasInfo, setShowPipasInfo] = useState(false);
  const { toast } = useToast();

  const form = useForm<PerfilForm>({
    resolver: zodResolver(perfilSchema),
    defaultValues: {
      nombre: usuario?.nombre || "",
      email: usuario?.email || "",
      telefono: usuario?.telefono || "",
      zona: usuario?.zona || "",
      ciudad: usuario?.ciudad || "",
      calle: usuario?.calle || "",
      numero: usuario?.numero || "",
      departamento: usuario?.departamento || "",
      codigoPostal: usuario?.codigoPostal || "",
    },
  });

  const emailForm = useForm<{ email: string }>({
    resolver: zodResolver(z.object({ email: z.string().email("Ingresa un email válido") })),
    defaultValues: {
      email: usuario?.email || "",
    },
  });

  if (!isAuthenticated) {
    setLocation("/login");
    return null;
  }

  const handleLogout = () => {
    logout();
    setLocation("/login");
  };

  const handleStartEditing = () => {
    form.reset({
      nombre: usuario?.nombre || "",
      email: usuario?.email || "",
      telefono: usuario?.telefono || "",
      zona: usuario?.zona || "",
      ciudad: usuario?.ciudad || "",
      calle: usuario?.calle || "",
      numero: usuario?.numero || "",
      departamento: usuario?.departamento || "",
      codigoPostal: usuario?.codigoPostal || "",
    });
    setIsEditing(true);
  };

  const handleCancelEditing = () => {
    setIsEditing(false);
    form.reset();
  };

  const handleSaveProfile = async (data: PerfilForm) => {
    if (!usuario?.id) return;
    
    setIsSaving(true);
    try {
      const response = await apiRequest("PUT", `/api/usuarios/${usuario.id}`, {
        nombre: data.nombre,
        telefono: data.telefono || null,
        zona: data.zona || null,
        ciudad: data.ciudad || null,
        calle: data.calle || null,
        numero: data.numero || null,
        departamento: data.departamento || null,
        codigoPostal: data.codigoPostal || null,
      });
      const updatedUsuario = await response.json();
      setUsuario(updatedUsuario);
      setIsEditing(false);
      
      // Mostrar modal de pipas si es la primera vez que completa zona/ciudad
      const hadZonaOrCiudad = usuario?.zona || usuario?.ciudad;
      const nowHasZonaOrCiudad = data.zona || data.ciudad;
      
      if (!hadZonaOrCiudad && nowHasZonaOrCiudad) {
        setShowPipasInfo(true);
      }
      
      toast({
        title: "Perfil actualizado",
        description: "Tus datos personales se han guardado correctamente.",
      });
    } catch (error: any) {
      toast({
        title: "Error al guardar",
        description: error.message || "No se pudieron guardar los cambios.",
        variant: "destructive",
      });
    } finally {
      setIsSaving(false);
    }
  };

  const handleOpenEmailDialog = () => {
    emailForm.reset({ email: usuario?.email || "" });
    setIsEmailDialogOpen(true);
  };

  const handleSaveEmail = async (data: { email: string }) => {
    if (!usuario?.id) return;
    
    setIsSaving(true);
    try {
      const response = await apiRequest("PUT", `/api/usuarios/${usuario.id}`, {
        email: data.email,
      });
      const updatedUsuario = await response.json();
      setUsuario(updatedUsuario);
      setIsEmailDialogOpen(false);
      toast({
        title: "Email actualizado",
        description: "Tu email se ha cambiado correctamente.",
      });
    } catch (error: any) {
      toast({
        title: "Error al cambiar email",
        description: error.message || "No se pudo cambiar el email.",
        variant: "destructive",
      });
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="px-4 py-6 space-y-6 max-w-2xl mx-auto">
      {/* Header */}
      <div className="text-center">
        <div className="w-20 h-20 bg-primary rounded-full flex items-center justify-center mx-auto mb-4">
          <User className="h-10 w-10 text-white" />
        </div>
        <h1 className="text-2xl font-bold text-gray-900 mb-2">Mi Perfil</h1>
        <p className="text-gray-600">Gestiona tu información personal</p>
      </div>

      {/* Información del usuario */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <span>Información Personal</span>
            {!isEditing ? (
              <Button variant="ghost" size="sm" onClick={handleStartEditing} data-testid="button-edit-profile">
                <Edit className="h-4 w-4 mr-2" />
                Editar
              </Button>
            ) : (
              <Button variant="ghost" size="sm" onClick={handleCancelEditing} data-testid="button-cancel-edit">
                <X className="h-4 w-4 mr-2" />
                Cancelar
              </Button>
            )}
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {!isEditing ? (
            <>
              <div className="flex items-center space-x-3">
                <User className="h-5 w-5 text-gray-400" />
                <div>
                  <p className="text-sm text-gray-600">Nombre</p>
                  <p className="font-medium" data-testid="text-nombre">{usuario?.nombre}</p>
                </div>
              </div>

              <div className="flex items-center space-x-3">
                <Mail className="h-5 w-5 text-gray-400" />
                <div>
                  <p className="text-sm text-gray-600">Email</p>
                  <p className="font-medium" data-testid="text-email">{usuario?.email}</p>
                </div>
              </div>

              {usuario?.telefono && (
                <div className="flex items-center space-x-3">
                  <Phone className="h-5 w-5 text-gray-400" />
                  <div>
                    <p className="text-sm text-gray-600">Teléfono</p>
                    <p className="font-medium" data-testid="text-telefono">{usuario.telefono}</p>
                  </div>
                </div>
              )}

              <div className="flex items-center space-x-3">
                <MapPin className="h-5 w-5 text-gray-400" />
                <div>
                  <p className="text-sm text-gray-600">Zona/Región</p>
                  <p className="font-medium" data-testid="text-zona">
                    {usuario?.zona || <span className="text-gray-400">No completado</span>}
                  </p>
                </div>
              </div>

              <div className="flex items-center space-x-3">
                <MapPin className="h-5 w-5 text-gray-400" />
                <div>
                  <p className="text-sm text-gray-600">Ciudad</p>
                  <p className="font-medium" data-testid="text-ciudad">
                    {usuario?.ciudad || <span className="text-gray-400">No completado</span>}
                  </p>
                </div>
              </div>

              {usuario?.calle && (
                <div className="flex items-center space-x-3">
                  <MapPin className="h-5 w-5 text-gray-400" />
                  <div>
                    <p className="text-sm text-gray-600">Dirección</p>
                    <p className="font-medium" data-testid="text-calle">
                      {usuario.calle} {usuario.numero && `#${usuario.numero}`}
                      {usuario.departamento && ` Apt. ${usuario.departamento}`}
                    </p>
                  </div>
                </div>
              )}

              {usuario?.codigoPostal && (
                <div className="flex items-center space-x-3">
                  <MapPin className="h-5 w-5 text-gray-400" />
                  <div>
                    <p className="text-sm text-gray-600">Código Postal</p>
                    <p className="font-medium" data-testid="text-codigoPostal">{usuario.codigoPostal}</p>
                  </div>
                </div>
              )}

              <div className="pt-4 border-t">
                <p className="text-sm text-gray-600">Miembro desde</p>
                <p className="font-medium">
                  {usuario?.fechaRegistro 
                    ? new Date(usuario.fechaRegistro).toLocaleDateString('es-AR', {
                        year: 'numeric',
                        month: 'long',
                        day: 'numeric'
                      })
                    : 'Fecha no disponible'
                  }
                </p>
              </div>
            </>
          ) : (
            <Form {...form}>
              <form onSubmit={form.handleSubmit(handleSaveProfile)} className="space-y-4">
                <FormField
                  control={form.control}
                  name="nombre"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Nombre</FormLabel>
                      <FormControl>
                        <Input 
                          placeholder="Tu nombre completo" 
                          data-testid="input-nombre"
                          {...field} 
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="telefono"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Teléfono (opcional)</FormLabel>
                      <FormControl>
                        <Input 
                          placeholder="Tu número de teléfono" 
                          data-testid="input-telefono"
                          {...field} 
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="zona"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Zona/Región (para ver pipas cercas de ti)</FormLabel>
                      <FormControl>
                        <Input 
                          placeholder="Ej: Sur, Centro, Norte, Zona 1, etc" 
                          data-testid="input-zona"
                          {...field} 
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="ciudad"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Ciudad (opcional)</FormLabel>
                      <FormControl>
                        <Input 
                          placeholder="Tu ciudad" 
                          data-testid="input-ciudad"
                          {...field} 
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <div className="border-t pt-4">
                  <h4 className="font-semibold text-gray-900 mb-3">Domicilio (opcional)</h4>
                  
                  <FormField
                    control={form.control}
                    name="calle"
                    render={({ field }) => (
                      <FormItem className="mb-3">
                        <FormLabel>Calle</FormLabel>
                        <FormControl>
                          <Input 
                            placeholder="Ej: Avenida Principal" 
                            data-testid="input-calle"
                            {...field} 
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <div className="grid grid-cols-2 gap-2 mb-3">
                    <FormField
                      control={form.control}
                      name="numero"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Número</FormLabel>
                          <FormControl>
                            <Input 
                              placeholder="123" 
                              data-testid="input-numero"
                              {...field} 
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="departamento"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Depto/Apt</FormLabel>
                          <FormControl>
                            <Input 
                              placeholder="101" 
                              data-testid="input-departamento"
                              {...field} 
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  <FormField
                    control={form.control}
                    name="codigoPostal"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Código Postal</FormLabel>
                        <FormControl>
                          <Input 
                            placeholder="CP: 28001" 
                            data-testid="input-codigoPostal"
                            {...field} 
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <Button 
                  type="submit" 
                  className="w-full"
                  disabled={isSaving}
                  data-testid="button-save-profile"
                >
                  <Save className="h-4 w-4 mr-2" />
                  {isSaving ? "Guardando..." : "Guardar cambios"}
                </Button>
              </form>
            </Form>
          )}
        </CardContent>
      </Card>

      {/* Estadísticas rápidas */}
      <Card>
        <CardHeader>
          <CardTitle>Resumen de Actividad</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 gap-4 text-center">
            <div>
              <div className="text-2xl font-bold text-primary">2</div>
              <div className="text-sm text-gray-600">Tanques registrados</div>
            </div>
            <div>
              <div className="text-2xl font-bold text-primary">5</div>
              <div className="text-sm text-gray-600">Cargas realizadas</div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Configuración */}
      <Card>
        <CardHeader>
          <CardTitle>Configuración</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <Button 
            variant="outline" 
            className="w-full justify-start"
            onClick={handleStartEditing}
            data-testid="button-config-edit-info"
          >
            <Edit className="h-4 w-4 mr-2" />
            Editar información personal
          </Button>
          
          <Button 
            variant="outline" 
            className="w-full justify-start"
            onClick={handleOpenEmailDialog}
            data-testid="button-config-change-email"
          >
            <Mail className="h-4 w-4 mr-2" />
            Cambiar email
          </Button>
        </CardContent>
      </Card>

      {/* Cerrar sesión */}
      <Card className="border-red-200">
        <CardContent className="p-4">
          <Button 
            variant="destructive" 
            className="w-full"
            onClick={handleLogout}
            data-testid="button-logout"
          >
            <LogOut className="h-4 w-4 mr-2" />
            Cerrar Sesión
          </Button>
        </CardContent>
      </Card>

      {/* Modal de información sobre pipas */}
      <PipasInfoModal 
        open={showPipasInfo} 
        onClose={() => setShowPipasInfo(false)} 
      />

      {/* Dialog para cambiar email */}
      <Dialog open={isEmailDialogOpen} onOpenChange={setIsEmailDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Cambiar Email</DialogTitle>
          </DialogHeader>
          <Form {...emailForm}>
            <form onSubmit={emailForm.handleSubmit(handleSaveEmail)} className="space-y-4">
              <FormField
                control={emailForm.control}
                name="email"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Nuevo email</FormLabel>
                    <FormControl>
                      <Input 
                        type="email"
                        placeholder="nuevo@email.com" 
                        data-testid="input-new-email"
                        {...field} 
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <DialogFooter>
                <Button 
                  type="button" 
                  variant="outline" 
                  onClick={() => setIsEmailDialogOpen(false)}
                  data-testid="button-cancel-email"
                >
                  Cancelar
                </Button>
                <Button 
                  type="submit"
                  disabled={isSaving}
                  data-testid="button-save-email"
                >
                  {isSaving ? "Guardando..." : "Guardar email"}
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>
    </div>
  );
}
