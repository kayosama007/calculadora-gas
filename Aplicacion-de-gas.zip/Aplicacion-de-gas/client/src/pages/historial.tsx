import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { History, Calendar, Fuel, DollarSign, MapPin, Loader2 } from "lucide-react";
import { useUser } from "@/contexts/user-context";
import { useLocation } from "wouter";
import { apiRequest } from "@/lib/queryClient";
import type { CargaConDetalles } from "@shared/schema";

export default function Historial() {
  const { usuario, isAuthenticated } = useUser();
  const [, setLocation] = useLocation();

  if (!isAuthenticated) {
    setLocation("/login");
    return null;
  }

  // Fetch cargas del usuario
  const { data: cargas = [], isLoading, error } = useQuery({
    queryKey: ["/api/cargas/usuario", usuario?.id],
    queryFn: async () => {
      if (!usuario?.id) return [];
      const response = await apiRequest("GET", `/api/cargas/usuario/${usuario.id}`);
      return response.json();
    },
    enabled: !!usuario?.id,
  });

  const formatMonto = (monto: number | string) => {
    const numMonto = typeof monto === 'string' ? parseFloat(monto) : monto;
    return new Intl.NumberFormat('es-AR', {
      style: 'currency',
      currency: 'ARS'
    }).format(numMonto);
  };

  const formatFecha = (fecha: string | Date) => {
    const dateObj = typeof fecha === 'string' ? new Date(fecha) : fecha;
    return dateObj.toLocaleDateString('es-AR', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric'
    });
  };

  const getPercentageBadge = (percentage: number | string) => {
    const numPercentage = typeof percentage === 'string' ? parseFloat(percentage) : percentage;
    if (numPercentage <= 80) return "default";
    return "destructive";
  };

  // Calcular estadísticas
  const totalCargas = cargas.length;
  const totalGastado = cargas.reduce((sum, carga) => {
    const monto = typeof carga.montoTotal === 'string' ? parseFloat(carga.montoTotal) : carga.montoTotal;
    return sum + monto;
  }, 0);

  return (
    <div className="px-4 py-6 space-y-6">
      {/* Header */}
      <div className="text-center">
        <div className="w-16 h-16 bg-primary rounded-full flex items-center justify-center mx-auto mb-4">
          <History className="h-8 w-8 text-white" />
        </div>
        <h1 className="text-2xl font-bold text-gray-900 mb-2">Historial de Cargas</h1>
        <p className="text-gray-600">Revisa todas tus cargas anteriores</p>
      </div>

      {/* Estadísticas rápidas */}
      <div className="grid grid-cols-2 gap-4">
        <Card>
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-primary">{totalCargas}</div>
            <div className="text-sm text-gray-600">Cargas realizadas</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-primary">{formatMonto(totalGastado)}</div>
            <div className="text-sm text-gray-600">Total gastado</div>
          </CardContent>
        </Card>
      </div>

      {/* Lista del historial */}
      <div className="space-y-4">
        {isLoading ? (
          <Card>
            <CardContent className="p-8 text-center">
              <Loader2 className="h-8 w-8 text-primary mx-auto mb-4 animate-spin" />
              <p className="text-gray-500">Cargando historial...</p>
            </CardContent>
          </Card>
        ) : error ? (
          <Card>
            <CardContent className="p-8 text-center">
              <p className="text-red-500 mb-4">Error al cargar historial</p>
            </CardContent>
          </Card>
        ) : cargas.length === 0 ? (
          <Card>
            <CardContent className="p-8 text-center">
              <History className="h-12 w-12 text-gray-300 mx-auto mb-4" />
              <p className="text-gray-500 mb-4">No tienes cargas registradas aún</p>
              <p className="text-sm text-gray-400">
                Cuando realices tu primera carga aparecerá aquí
              </p>
            </CardContent>
          </Card>
        ) : (
          cargas.map((carga: CargaConDetalles) => (
          <Card key={carga.id} className="bg-white">
            <CardContent className="p-4">
              <div className="flex justify-between items-start mb-3">
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                    <Fuel className="h-5 w-5 text-blue-600" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-gray-900">{carga.tanque?.marca} - {carga.tanque?.capacidad}L</h3>
                    <div className="flex items-center text-sm text-gray-600">
                      <Calendar className="h-3 w-3 mr-1" />
                      {formatFecha(carga.fechaCarga)}
                    </div>
                  </div>
                </div>
                <div className="text-right">
                  <div className="text-lg font-bold text-primary">
                    {formatMonto(carga.montoTotal)}
                  </div>
                  <div className="text-sm text-gray-600">
                    {carga.litrosCargados}L cargados
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4 text-sm">
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span className="text-gray-600">Nivel inicial:</span>
                    <span className="font-medium">{carga.porcentajeAnterior}%</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Nivel final:</span>
                    <Badge variant={getPercentageBadge(carga.porcentajeObjetivo)} className="text-xs">
                      {carga.porcentajeObjetivo}%
                    </Badge>
                  </div>
                </div>
                <div className="space-y-2">
                  <div className="flex items-center text-gray-600">
                    <MapPin className="h-3 w-3 mr-1" />
                    <span className="text-xs">{carga.estacion || "No especificada"}</span>
                  </div>
                  <div className="flex items-center text-gray-600">
                    <DollarSign className="h-3 w-3 mr-1" />
                    <span className="text-xs">
                      ${(parseFloat(carga.montoTotal) / parseFloat(carga.litrosCargados)).toFixed(2)}/L
                    </span>
                  </div>
                </div>
              </div>

              {/* Barra de progreso visual */}
              <div className="mt-3 pt-3 border-t border-gray-100">
                <div className="flex items-center space-x-2 text-xs text-gray-600">
                  <span>{carga.porcentajeAnterior}%</span>
                  <div className="flex-1 h-2 bg-gray-200 rounded-full overflow-hidden">
                    <div className="h-full bg-gradient-to-r from-red-400 via-yellow-400 to-green-400 rounded-full relative">
                      <div 
                        className="absolute top-0 left-0 h-full bg-white rounded-full"
                        style={{ width: `${100 - parseFloat(carga.porcentajeObjetivo)}%`, marginLeft: `${parseFloat(carga.porcentajeObjetivo)}%` }}
                      />
                    </div>
                  </div>
                  <span>{carga.porcentajeObjetivo}%</span>
                </div>
              </div>
            </CardContent>
          </Card>
          ))
        )}
      </div>
    </div>
  );
}