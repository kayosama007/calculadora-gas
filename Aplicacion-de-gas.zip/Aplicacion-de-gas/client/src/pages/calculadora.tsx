import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { Calculator, Fuel, AlertTriangle, CheckCircle, DollarSign, Percent } from "lucide-react";
import type { CalculoCarga, CalculoPorDinero } from "@shared/schema";

const calculoSchema = z.object({
  porcentajeActual: z.number().min(0, "Debe ser mayor a 0").max(100, "No puede ser mayor a 100"),
  porcentajeObjetivo: z.number().min(0, "Debe ser mayor a 0").max(100, "No puede ser mayor a 100"),
  capacidadTanque: z.number().min(1, "Debe ser mayor a 0"),
  costoPorLitro: z.number().min(0.01, "Debe ser mayor a 0"),
});

const calculoPorDineroSchema = z.object({
  porcentajeActual: z.number().min(0, "Debe ser mayor a 0").max(100, "No puede ser mayor a 100"),
  capacidadTanque: z.number().min(1, "Debe ser mayor a 0"),
  costoPorLitro: z.number().min(0.01, "Debe ser mayor a 0"),
  montoAPagar: z.number().min(0.01, "Debe ser mayor a 0"),
});

type CalculoForm = z.infer<typeof calculoSchema>;
type CalculoPorDineroForm = z.infer<typeof calculoPorDineroSchema>;

export default function Calculadora() {
  const [resultado, setResultado] = useState<CalculoCarga | null>(null);
  const [resultadoPorDinero, setResultadoPorDinero] = useState<CalculoPorDinero | null>(null);
  const [isCalculating, setIsCalculating] = useState(false);
  const [activeTab, setActiveTab] = useState("porcentaje");
  const { toast } = useToast();

  const form = useForm<CalculoForm>({
    resolver: zodResolver(calculoSchema),
    defaultValues: {
      porcentajeActual: 20,
      porcentajeObjetivo: 80,
      capacidadTanque: 60,
      costoPorLitro: 250,
    },
  });

  const formPorDinero = useForm<CalculoPorDineroForm>({
    resolver: zodResolver(calculoPorDineroSchema),
    defaultValues: {
      porcentajeActual: 20,
      capacidadTanque: 60,
      costoPorLitro: 250,
      montoAPagar: 5000,
    },
  });

  const handleCalcular = async (data: CalculoForm) => {
    setIsCalculating(true);
    setResultadoPorDinero(null); // Limpiar resultado anterior
    try {
      const response = await apiRequest("POST", "/api/calcular", data);
      const calculo: CalculoCarga = await response.json();
      setResultado(calculo);
      
      if (!calculo.esSeguro) {
        toast({
          title: "Advertencia de seguridad",
          description: calculo.advertencia,
          variant: "destructive",
        });
      }
    } catch (error: any) {
      toast({
        title: "Error en el cálculo",
        description: error.message || "No se pudo realizar el cálculo.",
        variant: "destructive",
      });
    } finally {
      setIsCalculating(false);
    }
  };

  const handleCalcularPorDinero = async (data: CalculoPorDineroForm) => {
    setIsCalculating(true);
    setResultado(null); // Limpiar resultado anterior
    try {
      const response = await apiRequest("POST", "/api/calcular-por-dinero", data);
      const calculo: CalculoPorDinero = await response.json();
      setResultadoPorDinero(calculo);
      
      if (!calculo.esSeguro) {
        toast({
          title: "Advertencia de seguridad",
          description: calculo.advertencia,
          variant: "destructive",
        });
      }
    } catch (error: any) {
      toast({
        title: "Error en el cálculo",
        description: error.message || "No se pudo realizar el cálculo por dinero.",
        variant: "destructive",
      });
    } finally {
      setIsCalculating(false);
    }
  };

  const formatMonto = (monto: number) => {
    return new Intl.NumberFormat('es-AR', {
      style: 'currency',
      currency: 'ARS'
    }).format(monto);
  };

  const getPercentageColor = (percentage: number) => {
    if (percentage <= 50) return "text-green-600";
    if (percentage <= 80) return "text-yellow-600";
    return "text-red-600";
  };

  const getPercentageIcon = (percentage: number) => {
    if (percentage <= 80) return CheckCircle;
    return AlertTriangle;
  };

  return (
    <div className="px-4 py-6 space-y-6 max-w-2xl mx-auto">
      {/* Header */}
      <div className="text-center">
        <div className="w-16 h-16 bg-primary rounded-full flex items-center justify-center mx-auto mb-4">
          <Calculator className="h-8 w-8 text-white" />
        </div>
        <h1 className="text-2xl font-bold text-gray-900 mb-2">Calculadora de Gas</h1>
        <p className="text-gray-600">Calcula cuánto gas necesitas o cuánto puedes comprar</p>
      </div>

      {/* Formularios con pestañas */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Fuel className="h-5 w-5" />
            Tipo de cálculo
          </CardTitle>
        </CardHeader>
        <CardContent>
          <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="porcentaje" className="flex items-center gap-2" data-testid="tab-porcentaje">
                <Percent className="h-4 w-4" />
                Por Porcentaje
              </TabsTrigger>
              <TabsTrigger value="dinero" className="flex items-center gap-2" data-testid="tab-dinero">
                <DollarSign className="h-4 w-4" />
                Por Dinero
              </TabsTrigger>
            </TabsList>
            
            <TabsContent value="porcentaje" className="mt-6">
              <Form {...form}>
                <form onSubmit={form.handleSubmit(handleCalcular)} className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <FormField
                      control={form.control}
                      name="porcentajeActual"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Porcentaje actual del tanque (%)</FormLabel>
                          <FormControl>
                            <Input
                              type="number"
                              min="0"
                              max="100"
                              data-testid="input-porcentaje-actual"
                              {...field}
                              onChange={(e) => field.onChange(parseFloat(e.target.value) || 0)}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="porcentajeObjetivo"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Porcentaje objetivo (%)</FormLabel>
                          <FormControl>
                            <Input
                              type="number"
                              min="0"
                              max="100"
                              data-testid="input-porcentaje-objetivo"
                              {...field}
                              onChange={(e) => field.onChange(parseFloat(e.target.value) || 0)}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="capacidadTanque"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Capacidad del tanque (litros)</FormLabel>
                          <FormControl>
                            <Input
                              type="number"
                              min="1"
                              step="0.1"
                              data-testid="input-capacidad-tanque"
                              {...field}
                              onChange={(e) => field.onChange(parseFloat(e.target.value) || 0)}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="costoPorLitro"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Costo por litro ($)</FormLabel>
                          <FormControl>
                            <Input
                              type="number"
                              min="0.01"
                              step="0.01"
                              data-testid="input-costo-por-litro"
                              {...field}
                              onChange={(e) => field.onChange(parseFloat(e.target.value) || 0)}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  <Button
                    type="submit"
                    className="w-full bg-primary hover:bg-primary/90"
                    disabled={isCalculating}
                    data-testid="button-calcular-por-porcentaje"
                  >
                    {isCalculating ? "Calculando..." : "Calcular Monto"}
                  </Button>
                </form>
              </Form>
            </TabsContent>

            <TabsContent value="dinero" className="mt-6">
              <Form {...formPorDinero}>
                <form onSubmit={formPorDinero.handleSubmit(handleCalcularPorDinero)} className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <FormField
                      control={formPorDinero.control}
                      name="porcentajeActual"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Porcentaje actual del tanque (%)</FormLabel>
                          <FormControl>
                            <Input
                              type="number"
                              min="0"
                              max="100"
                              data-testid="input-dinero-porcentaje-actual"
                              {...field}
                              onChange={(e) => field.onChange(parseFloat(e.target.value) || 0)}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={formPorDinero.control}
                      name="montoAPagar"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Dinero disponible ($)</FormLabel>
                          <FormControl>
                            <Input
                              type="number"
                              min="0.01"
                              step="0.01"
                              data-testid="input-monto-a-pagar"
                              {...field}
                              onChange={(e) => field.onChange(parseFloat(e.target.value) || 0)}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={formPorDinero.control}
                      name="capacidadTanque"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Capacidad del tanque (litros)</FormLabel>
                          <FormControl>
                            <Input
                              type="number"
                              min="1"
                              step="0.1"
                              data-testid="input-dinero-capacidad-tanque"
                              {...field}
                              onChange={(e) => field.onChange(parseFloat(e.target.value) || 0)}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={formPorDinero.control}
                      name="costoPorLitro"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Costo por litro ($)</FormLabel>
                          <FormControl>
                            <Input
                              type="number"
                              min="0.01"
                              step="0.01"
                              data-testid="input-dinero-costo-por-litro"
                              {...field}
                              onChange={(e) => field.onChange(parseFloat(e.target.value) || 0)}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  <Button
                    type="submit"
                    className="w-full bg-primary hover:bg-primary/90"
                    disabled={isCalculating}
                    data-testid="button-calcular-por-dinero"
                  >
                    {isCalculating ? "Calculando..." : "Calcular Litros y Porcentaje"}
                  </Button>
                </form>
              </Form>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>

      {/* Advertencia de seguridad */}
      <Alert className="border-orange-200 bg-orange-50">
        <AlertTriangle className="h-4 w-4 text-orange-600" />
        <AlertDescription className="text-orange-800">
          <strong>Importante:</strong> Por seguridad, no se recomienda llenar los tanques de gas más del 80%. 
          Más del 85% puede ser peligroso.
        </AlertDescription>
      </Alert>

      {/* Resultados */}
      {(resultado || resultadoPorDinero) && (
        <Card className={`border-2 ${(resultado?.esSeguro ?? resultadoPorDinero?.esSeguro) ? 'border-green-200 bg-green-50' : 'border-red-200 bg-red-50'}`}>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <DollarSign className="h-5 w-5" />
              Resultado del cálculo
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {/* Advertencia si existe */}
            {(resultado?.advertencia || resultadoPorDinero?.advertencia) && (
              <Alert className={`${(resultado?.esSeguro ?? resultadoPorDinero?.esSeguro) ? 'border-yellow-200 bg-yellow-50' : 'border-red-200 bg-red-50'}`}>
                <AlertTriangle className={`h-4 w-4 ${(resultado?.esSeguro ?? resultadoPorDinero?.esSeguro) ? 'text-yellow-600' : 'text-red-600'}`} />
                <AlertDescription className={`${(resultado?.esSeguro ?? resultadoPorDinero?.esSeguro) ? 'text-yellow-800' : 'text-red-800'}`}>
                  {resultado?.advertencia || resultadoPorDinero?.advertencia}
                </AlertDescription>
              </Alert>
            )}

            {/* Resultados para cálculo por porcentaje */}
            {resultado && (
              <>
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span className="text-gray-600">Porcentaje actual:</span>
                      <span className={`font-semibold ${getPercentageColor(resultado.porcentajeActual)}`} data-testid="result-porcentaje-actual">
                        {resultado.porcentajeActual}%
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Porcentaje objetivo:</span>
                      <span className={`font-semibold ${getPercentageColor(resultado.porcentajeObjetivo)}`} data-testid="result-porcentaje-objetivo">
                        {resultado.porcentajeObjetivo}%
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Capacidad del tanque:</span>
                      <span className="font-semibold" data-testid="result-capacidad-tanque">{resultado.capacidadTanque}L</span>
                    </div>
                  </div>
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span className="text-gray-600">Costo por litro:</span>
                      <span className="font-semibold" data-testid="result-costo-por-litro">{formatMonto(resultado.costoPorLitro)}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Litros a cargar:</span>
                      <span className="font-semibold text-primary" data-testid="result-litros-a-cargar">{resultado.litrosACargar.toFixed(2)}L</span>
                    </div>
                  </div>
                </div>

                {/* Monto total destacado */}
                <div className="border-t pt-4">
                  <div className="text-center">
                    <p className="text-sm text-gray-600 mb-1">Monto total a pagar:</p>
                    <p className="text-3xl font-bold text-primary" data-testid="result-monto-total">
                      {formatMonto(resultado.montoAPagar)}
                    </p>
                  </div>
                </div>

                {/* Indicador de seguridad */}
                <div className="flex items-center justify-center gap-2 pt-2">
                  {(() => {
                    const Icon = getPercentageIcon(resultado.porcentajeObjetivo);
                    return (
                      <>
                        <Icon className={`h-5 w-5 ${resultado.esSeguro ? 'text-green-600' : 'text-red-600'}`} />
                        <span className={`font-medium ${resultado.esSeguro ? 'text-green-600' : 'text-red-600'}`} data-testid="result-seguridad">
                          {resultado.esSeguro ? 'Carga segura' : 'Carga no recomendada'}
                        </span>
                      </>
                    );
                  })()}
                </div>
              </>
            )}

            {/* Resultados para cálculo por dinero */}
            {resultadoPorDinero && (
              <>
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span className="text-gray-600">Porcentaje actual:</span>
                      <span className={`font-semibold ${getPercentageColor(resultadoPorDinero.porcentajeActual)}`} data-testid="result-dinero-porcentaje-actual">
                        {resultadoPorDinero.porcentajeActual}%
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Porcentaje final:</span>
                      <span className={`font-semibold ${getPercentageColor(resultadoPorDinero.porcentajeFinal)}`} data-testid="result-dinero-porcentaje-final">
                        {resultadoPorDinero.porcentajeFinal.toFixed(1)}%
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Capacidad del tanque:</span>
                      <span className="font-semibold" data-testid="result-dinero-capacidad-tanque">{resultadoPorDinero.capacidadTanque}L</span>
                    </div>
                  </div>
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span className="text-gray-600">Costo por litro:</span>
                      <span className="font-semibold" data-testid="result-dinero-costo-por-litro">{formatMonto(resultadoPorDinero.costoPorLitro)}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Litros que puedes comprar:</span>
                      <span className="font-semibold text-primary" data-testid="result-dinero-litros-posibles">{resultadoPorDinero.litrosPosibles.toFixed(2)}L</span>
                    </div>
                  </div>
                </div>

                {/* Dinero disponible destacado */}
                <div className="border-t pt-4">
                  <div className="text-center">
                    <p className="text-sm text-gray-600 mb-1">Dinero disponible:</p>
                    <p className="text-3xl font-bold text-primary" data-testid="result-dinero-monto-disponible">
                      {formatMonto(resultadoPorDinero.montoAPagar)}
                    </p>
                  </div>
                </div>

                {/* Indicador de seguridad */}
                <div className="flex items-center justify-center gap-2 pt-2">
                  {(() => {
                    const Icon = getPercentageIcon(resultadoPorDinero.porcentajeFinal);
                    return (
                      <>
                        <Icon className={`h-5 w-5 ${resultadoPorDinero.esSeguro ? 'text-green-600' : 'text-red-600'}`} />
                        <span className={`font-medium ${resultadoPorDinero.esSeguro ? 'text-green-600' : 'text-red-600'}`} data-testid="result-dinero-seguridad">
                          {resultadoPorDinero.esSeguro ? 'Carga segura' : 'Carga no recomendada'}
                        </span>
                      </>
                    );
                  })()}
                </div>
              </>
            )}
          </CardContent>
        </Card>
      )}
    </div>
  );
}