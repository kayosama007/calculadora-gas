import { useEffect, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Settings, Users, UserCheck, AlertCircle, Trash2, Zap, Star, MapPin, Lock } from "lucide-react";
import { useUser } from "@/contexts/user-context";
import { useLocation } from "wouter";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import type { Usuario, ProveedorConEvaluaciones } from "@shared/schema";

export default function Admin() {
  const { usuario, isAuthenticated } = useUser();
  const [, setLocation] = useLocation();
  const [usuarios, setUsuarios] = useState<Usuario[]>([]);
  const [proveedores, setProveedores] = useState<ProveedorConEvaluaciones[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [diasInactivos, setDiasInactivos] = useState(30);
  const [isCleaningUp, setIsCleaningUp] = useState(false);
  const [passwordVerified, setPasswordVerified] = useState(false);
  const [adminPassword, setAdminPassword] = useState("");
  const [showPasswordDialog, setShowPasswordDialog] = useState(false);
  const [newEmail, setNewEmail] = useState(usuario?.email || "");
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [isUpdatingCredentials, setIsUpdatingCredentials] = useState(false);
  const [cuentaBancaria, setCuentaBancaria] = useState(usuario?.cuentaBancaria || "");
  const { toast } = useToast();

  useEffect(() => {
    if (usuario) {
      setNewEmail(usuario.email);
      setCuentaBancaria(usuario.cuentaBancaria || "");
    }
  }, [usuario]);

  if (!isAuthenticated) {
    setLocation("/login");
    return null;
  }

  if (!usuario?.esAdmin) {
    setLocation("/");
    return null;
  }

  useEffect(() => {
    setShowPasswordDialog(true);
  }, []);

  useEffect(() => {
    if (passwordVerified) {
      fetchUsuarios();
      fetchProveedores();
    }
  }, [passwordVerified]);

  const handleVerifyPassword = async () => {
    if (!adminPassword.trim()) {
      toast({ title: "Error", description: "Ingresa la contraseña", variant: "destructive" });
      return;
    }

    try {
      const response = await apiRequest("POST", "/api/admin/verify-password", {
        usuarioId: usuario?.id,
        password: adminPassword,
      });
      const data = await response.json();
      if (data.valid) {
        setPasswordVerified(true);
        setShowPasswordDialog(false);
        toast({ title: "Éxito", description: "Contraseña verificada" });
      } else {
        toast({ title: "Error", description: "Contraseña incorrecta", variant: "destructive" });
      }
    } catch (error) {
      toast({ title: "Error", description: "Error al verificar contraseña", variant: "destructive" });
    }
  };

  const fetchUsuarios = async () => {
    setIsLoading(true);
    try {
      const response = await apiRequest("GET", "/api/admin/usuarios");
      const data = await response.json();
      setUsuarios(data);
    } catch (error: any) {
      toast({
        title: "Error al cargar usuarios",
        description: error.message,
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const fetchProveedores = async () => {
    try {
      const response = await apiRequest("GET", "/api/proveedores");
      const data = await response.json();
      setProveedores(data);
    } catch (error: any) {
      toast({
        title: "Error al cargar proveedores",
        description: error.message,
        variant: "destructive",
      });
    }
  };

  const handleMarcarConfiable = async (proveedorId: number, esConfiable: boolean) => {
    try {
      const response = await apiRequest("PUT", `/api/admin/proveedores/${proveedorId}/confiable`, {
        confiable: !esConfiable,
      });
      await response.json();
      fetchProveedores();
      toast({
        title: "Éxito",
        description: `Proveedor marcado como ${!esConfiable ? "confiable" : "no confiable"}`,
      });
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    }
  };

  const handleActualizarEstrellas = async (proveedorId: number, estrellas: number) => {
    try {
      await apiRequest("PUT", `/api/admin/proveedores/${proveedorId}/estrellas`, {
        estrellas,
      });
      fetchProveedores();
      toast({
        title: "Éxito",
        description: `Confiabilidad actualizada a ${estrellas} estrellas`,
      });
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    }
  };

  const handleEliminarProveedor = async (proveedorId: number, nombre: string) => {
    if (!confirm(`¿Deseas eliminar a ${nombre}? Esta acción no se puede deshacer.`)) return;

    try {
      await apiRequest("DELETE", `/api/admin/proveedores/${proveedorId}`);
      fetchProveedores();
      toast({
        title: "Éxito",
        description: "Proveedor eliminado correctamente",
      });
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    }
  };

  const handleToggleAdmin = async (userId: number, currentAdmin: boolean) => {
    try {
      const response = await apiRequest("PUT", `/api/admin/usuarios/${userId}/admin`, {
        esAdmin: !currentAdmin,
      });
      const updatedUser = await response.json();
      setUsuarios(usuarios.map(u => u.id === userId ? updatedUser : u));
      toast({
        title: "Usuario actualizado",
        description: `El usuario ahora es ${!currentAdmin ? "administrador" : "usuario normal"}`,
      });
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    }
  };

  const handleDeleteUser = async (userId: number) => {
    if (!confirm("¿Estás seguro de que deseas desactivar este usuario?")) return;

    try {
      await apiRequest("DELETE", `/api/admin/usuarios/${userId}`);
      setUsuarios(usuarios.filter(u => u.id !== userId));
      toast({
        title: "Usuario desactivado",
        description: "El usuario ha sido desactivado correctamente.",
      });
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    }
  };

  const handleDeleteUserPermanently = async (userId: number, userName: string) => {
    if (!confirm(`¿Eliminar permanentemente a ${userName}? Esta acción no se puede deshacer.`)) return;

    try {
      await apiRequest("DELETE", `/api/admin/usuarios/${userId}/permanent`);
      setUsuarios(usuarios.filter(u => u.id !== userId));
      toast({
        title: "Usuario eliminado",
        description: "El usuario ha sido eliminado permanentemente.",
      });
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    }
  };

  const handleLimpiarUsuariosViejos = async () => {
    if (!confirm(`¿Desactivar usuarios inactivos por más de ${diasInactivos} días? Esta acción no se puede deshacer.`)) return;

    setIsCleaningUp(true);
    try {
      const response = await apiRequest("POST", "/api/admin/limpiar-usuarios", {
        diasInactivos,
      });
      const data = await response.json();
      setUsuarios(usuarios.filter(u => {
        const diasRegistro = Math.floor((new Date().getTime() - new Date(u.fechaRegistro!).getTime()) / (1000 * 60 * 60 * 24));
        return diasRegistro < diasInactivos || u.esAdmin;
      }));
      toast({
        title: "Limpieza completada",
        description: `${data.eliminados} usuarios han sido desactivados.`,
      });
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    } finally {
      setIsCleaningUp(false);
    }
  };

  const handleUpdateCredentials = async () => {
    if (!newEmail.trim()) {
      toast({ title: "Error", description: "El email es requerido", variant: "destructive" });
      return;
    }

    if (newPassword && newPassword !== confirmPassword) {
      toast({ title: "Error", description: "Las contraseñas no coinciden", variant: "destructive" });
      return;
    }

    setIsUpdatingCredentials(true);
    try {
      // 1. Actualizar email/usuario y cuenta bancaria
      await apiRequest("PUT", `/api/usuarios/${usuario?.id}`, {
        email: newEmail,
        cuentaBancaria: cuentaBancaria,
      });

      // 2. Actualizar contraseña de panel si se proporcionó una nueva
      if (newPassword) {
        await apiRequest("POST", "/api/admin/set-password", {
          usuarioId: usuario?.id,
          password: newPassword,
        });
      }

      toast({
        title: "Éxito",
        description: "Credenciales de administrador actualizadas correctamente. Por favor, reinicia sesión si cambiaste tu email.",
      });
      
      // Actualizar estado local del contexto si es necesario (el usuario sigue logueado con el ID)
      // Aunque lo ideal es que el usuario sepa que su "login" ahora es el nuevo email
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message || "Error al actualizar credenciales",
        variant: "destructive",
      });
    } finally {
      setIsUpdatingCredentials(false);
    }
  };

  const totalUsuarios = usuarios.length;
  const admins = usuarios.filter(u => u.esAdmin).length;
  const usuariosActivos = usuarios.filter(u => u.activo).length;

  if (!passwordVerified) {
    return (
      <Dialog open={showPasswordDialog} onOpenChange={setShowPasswordDialog}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Lock className="h-5 w-5" />
              Acceso Restringido - Panel de Administrador
            </DialogTitle>
            <DialogDescription>
              Ingresa tu contraseña de administrador para acceder
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div>
              <label className="text-sm font-medium block mb-2">Contraseña de Administrador</label>
              <input
                type="password"
                placeholder="Ingresa tu contraseña"
                value={adminPassword}
                onChange={(e) => setAdminPassword(e.target.value)}
                onKeyPress={(e) => e.key === "Enter" && handleVerifyPassword()}
                className="w-full px-3 py-2 border rounded"
                autoFocus
                data-testid="input-admin-password"
              />
            </div>
            <Button 
              onClick={handleVerifyPassword} 
              className="w-full"
              data-testid="button-verify-password"
            >
              Acceder al Panel
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    );
  }

  return (
    <div className="px-4 py-6 space-y-6 max-w-5xl mx-auto">
      {/* Header */}
      <div className="text-center">
        <div className="w-16 h-16 bg-primary rounded-full flex items-center justify-center mx-auto mb-4">
          <Settings className="h-8 w-8 text-white" />
        </div>
        <h1 className="text-2xl font-bold text-gray-900 mb-2">Panel de Administrador</h1>
        <p className="text-gray-600">Gestiona usuarios y la aplicación</p>
      </div>

      {/* Limpieza de usuarios viejos */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card className="bg-gradient-to-r from-red-50 to-red-100 border-red-200">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-red-900">
              <Zap className="h-5 w-5" />
              Limpiar usuarios inactivos
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div>
                <label className="text-sm font-medium text-red-900 block mb-2">
                  Desactivar usuarios sin actividad por más de:
                </label>
                <div className="flex gap-2">
                  <input
                    type="number"
                    min="1"
                    max="365"
                    value={diasInactivos}
                    onChange={(e) => setDiasInactivos(Math.max(1, parseInt(e.target.value) || 30))}
                    className="flex-1 px-3 py-2 border border-red-200 rounded-md text-sm bg-white"
                    disabled={isCleaningUp}
                    data-testid="input-dias-inactivos"
                  />
                  <span className="px-3 py-2 bg-white border border-red-200 rounded-md text-sm font-medium text-red-900">
                    días
                  </span>
                </div>
                <p className="text-xs text-red-700 mt-2">
                  Solo se desactivarán usuarios regulares, los administradores no serán eliminados.
                </p>
              </div>
              <Button
                onClick={handleLimpiarUsuariosViejos}
                disabled={isCleaningUp}
                variant="destructive"
                className="w-full"
                data-testid="button-cleanup-users"
              >
                {isCleaningUp ? "Limpiando..." : "Ejecutar limpieza"}
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Cambio de credenciales admin */}
        <Card className="border-primary/20">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-primary">
              <Lock className="h-5 w-5" />
              Mis Credenciales (Admin)
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div>
                <label className="text-sm font-medium block mb-1">Email de Usuario</label>
                <input
                  type="email"
                  value={newEmail}
                  onChange={(e) => setNewEmail(e.target.value)}
                  className="w-full px-3 py-2 border rounded-md text-sm"
                  placeholder="nuevo@email.com"
                />
              </div>
              <div>
                <label className="text-sm font-medium block mb-1">Nueva Contraseña del Panel</label>
                <input
                  type="password"
                  value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                  className="w-full px-3 py-2 border rounded-md text-sm"
                  placeholder="Dejar en blanco para no cambiar"
                />
              </div>
              {newPassword && (
                <div>
                  <label className="text-sm font-medium block mb-1">Confirmar Contraseña</label>
                  <input
                    type="password"
                    value={confirmPassword}
                    onChange={(e) => setConfirmPassword(e.target.value)}
                    className="w-full px-3 py-2 border rounded-md text-sm"
                    placeholder="Repite la contraseña"
                  />
                </div>
              )}
              <div>
                <label className="text-sm font-medium block mb-1">Cuenta Bancaria (para donaciones)</label>
                <textarea
                  value={cuentaBancaria}
                  onChange={(e) => setCuentaBancaria(e.target.value)}
                  className="w-full px-3 py-2 border rounded-md text-sm min-h-[80px]"
                  placeholder="Ej: CLABE: 0123... Banco: ... Beneficiario: ..."
                />
                <p className="text-[10px] text-gray-500 mt-1">
                  Esta información se mostrará a los usuarios en el Dashboard para que puedan realizar donaciones.
                </p>
              </div>
              <Button
                onClick={handleUpdateCredentials}
                disabled={isUpdatingCredentials}
                className="w-full"
              >
                {isUpdatingCredentials ? "Guardando..." : "Actualizar mis datos"}
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Estadísticas */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-600 flex items-center gap-2">
              <Users className="h-4 w-4" />
              Total de usuarios
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-primary" data-testid="stat-total-users">{totalUsuarios}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-600 flex items-center gap-2">
              <UserCheck className="h-4 w-4" />
              Administradores
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-orange-600" data-testid="stat-admins">{admins}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-600 flex items-center gap-2">
              <AlertCircle className="h-4 w-4" />
              Usuarios activos
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600" data-testid="stat-active-users">{usuariosActivos}</div>
          </CardContent>
        </Card>
      </div>

      {/* Gestión de Proveedores */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <MapPin className="h-5 w-5" />
            Gestión de Proveedores de Gas (Pipas)
          </CardTitle>
        </CardHeader>
        <CardContent>
          {proveedores.length === 0 ? (
            <div className="text-center py-8 text-gray-500">No hay proveedores registrados aún</div>
          ) : (
            <div className="grid gap-4">
              {proveedores.map((prov) => (
                <div key={prov.id} className={`p-4 border rounded-lg ${prov.confiable ? "border-green-300 bg-green-50" : "border-gray-200"}`}>
                  <div className="flex justify-between items-start mb-2">
                    <div className="flex-1">
                      <h3 className="font-semibold text-gray-900">{prov.nombre}</h3>
                      <p className="text-sm text-gray-600">📞 {prov.telefono}</p>
                      {(prov.zona || prov.ciudad) && (
                        <p className="text-sm text-gray-600">📍 {prov.zona}{prov.ciudad ? `, ${prov.ciudad}` : ""}</p>
                      )}
                    </div>
                    {prov.totalEvaluaciones > 0 && (
                      <div className="text-right">
                        <div className="flex items-center gap-1 text-yellow-500 text-sm">
                          <Star className="h-4 w-4 fill-current" />
                          <span className="font-bold">{prov.promedioCalificacion}</span>
                        </div>
                        <p className="text-xs text-gray-500">{prov.totalEvaluaciones} evaluaciones</p>
                      </div>
                    )}
                  </div>
                  <div className="space-y-3">
                    {/* Botón marcar confiable */}
                    <Button
                      size="sm"
                      onClick={() => handleMarcarConfiable(prov.id, !!prov.confiable)}
                      className={prov.confiable ? "bg-green-600 hover:bg-green-700 w-full" : "w-full"}
                      data-testid={`button-trust-provider-${prov.id}`}
                    >
                      {prov.confiable ? "✓ Confiable" : "Marcar como confiable"}
                    </Button>

                    {/* Selector de estrellas de confiabilidad */}
                    <div className="flex gap-2 items-center">
                      <span className="text-xs font-medium text-gray-600 whitespace-nowrap">Confiabilidad:</span>
                      <div className="flex gap-1">
                        {[0, 1, 2, 3, 4, 5].map((star) => (
                          <button
                            key={star}
                            onClick={() => handleActualizarEstrellas(prov.id, star)}
                            className={`p-1 rounded transition ${
                              (prov.estrellas ?? 0) >= star
                                ? "text-yellow-500 bg-yellow-50"
                                : "text-gray-300 hover:text-gray-400"
                            }`}
                            title={`${star} ${star === 1 ? "estrella" : "estrellas"}`}
                            data-testid={`button-star-${prov.id}-${star}`}
                          >
                            <Star className="h-4 w-4 fill-current" />
                          </button>
                        ))}
                      </div>
                      <span className="text-xs font-semibold text-yellow-600">
                        {prov.estrellas ?? 0}
                      </span>
                    </div>

                    {/* Botón eliminar */}
                    <Button
                      size="sm"
                      variant="destructive"
                      onClick={() => handleEliminarProveedor(prov.id, prov.nombre)}
                      className="w-full"
                      data-testid={`button-delete-provider-admin-${prov.id}`}
                    >
                      <Trash2 className="h-4 w-4 mr-2" />
                      Eliminar
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Lista de usuarios */}
      <Card>
        <CardHeader>
          <CardTitle>Gestión de Usuarios</CardTitle>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="text-center py-8 text-gray-500">Cargando usuarios...</div>
          ) : usuarios.length === 0 ? (
            <div className="text-center py-8 text-gray-500">No hay usuarios registrados</div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="border-b bg-gray-50">
                  <tr>
                    <th className="px-4 py-2 text-left font-semibold">Nombre</th>
                    <th className="px-4 py-2 text-left font-semibold">Email</th>
                    <th className="px-4 py-2 text-left font-semibold">Teléfono</th>
                    <th className="px-4 py-2 text-left font-semibold">Estado</th>
                    <th className="px-4 py-2 text-left font-semibold">Rol</th>
                    <th className="px-4 py-2 text-left font-semibold">Acciones</th>
                  </tr>
                </thead>
                <tbody>
                  {usuarios.map((u) => (
                    <tr key={u.id} className="border-b hover:bg-gray-50" data-testid={`user-row-${u.id}`}>
                      <td className="px-4 py-3 font-medium">{u.nombre}</td>
                      <td className="px-4 py-3">{u.email}</td>
                      <td className="px-4 py-3">{u.telefono || "-"}</td>
                      <td className="px-4 py-3">
                        <span className={`px-2 py-1 rounded text-xs font-medium ${
                          u.activo ? "bg-green-100 text-green-800" : "bg-red-100 text-red-800"
                        }`}>
                          {u.activo ? "Activo" : "Inactivo"}
                        </span>
                      </td>
                      <td className="px-4 py-3">
                        <span className={`px-2 py-1 rounded text-xs font-medium ${
                          (u.esAdmin ?? false) ? "bg-orange-100 text-orange-800" : "bg-blue-100 text-blue-800"
                        }`}>
                          {(u.esAdmin ?? false) ? "Admin" : "Usuario"}
                        </span>
                      </td>
                      <td className="px-4 py-3 space-x-2">
                        {usuario?.id !== u.id && (
                          <>
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => handleToggleAdmin(u.id, u.esAdmin ?? false)}
                              data-testid={`button-toggle-admin-${u.id}`}
                            >
                              {(u.esAdmin ?? false) ? "Remover Admin" : "Hacer Admin"}
                            </Button>
                            {u.activo && (
                              <Button
                                size="sm"
                                variant="destructive"
                                onClick={() => handleDeleteUser(u.id)}
                                data-testid={`button-deactivate-user-${u.id}`}
                              >
                                <Trash2 className="h-3 w-3 mr-1" />
                                Desactivar
                              </Button>
                            )}
                            <Button
                              size="sm"
                              variant="ghost"
                              className="text-red-600 hover:bg-red-50 hover:text-red-700"
                              onClick={() => handleDeleteUserPermanently(u.id, u.nombre)}
                              data-testid={`button-delete-permanently-${u.id}`}
                            >
                              <Trash2 className="h-3 w-3 mr-1" />
                              Eliminar
                            </Button>
                          </>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
