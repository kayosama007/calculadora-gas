import { useUser } from "@/contexts/user-context";
import { useLocation } from "wouter";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Calculator, Fuel, History, Settings, TrendingUp, MapPin } from "lucide-react";

export default function Dashboard() {
  const { usuario, isAuthenticated } = useUser();
  const [, setLocation] = useLocation();

  if (!isAuthenticated) {
    setLocation("/login");
    return null;
  }

  const quickActions = [
    {
      title: "Calcular Carga",
      description: "Calcula el monto a pagar por tu carga de gas",
      icon: Calculator,
      color: "bg-primary",
      path: "/calculadora"
    },
    {
      title: "Mis Tanques",
      description: "Gestiona tus tanques de gas registrados",
      icon: Fuel,
      color: "bg-success",
      path: "/tanques"
    },
    {
      title: "Pipas Cercanas",
      description: "Encuentra proveedores de gas cerca de ti",
      icon: MapPin,
      color: "bg-green-600",
      path: "/pipas"
    },
    {
      title: "Historial",
      description: "Revisa tu historial de cargas anteriores",
      icon: History,
      color: "bg-warning",
      path: "/historial"
    }
  ];

  return (
    <div className="px-4 py-6 space-y-6">
      {/* Welcome Section */}
      <div className="text-center">
        <div className="w-20 h-20 bg-primary rounded-full flex items-center justify-center mx-auto mb-4">
          <Fuel className="h-10 w-10 text-white" />
        </div>
        <h1 className="text-2xl font-bold text-gray-900 mb-2">
          ¡Hola, {usuario?.nombre}!
        </h1>
        <p className="text-gray-600">
          Bienvenido a tu calculadora de gas estacionario
        </p>
      </div>

      {/* Quick Calculator Card */}
      <Card className="bg-gradient-to-r from-blue-500 to-blue-600 text-white">
        <CardContent className="p-6">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-lg font-semibold mb-2">Calculadora Rápida</h3>
              <p className="text-blue-100 mb-4">
                Calcula instantáneamente cuánto pagarás por tu carga de gas
              </p>
              <Button 
                variant="secondary" 
                onClick={() => setLocation("/calculadora")}
                className="bg-white text-blue-600 hover:bg-blue-50"
              >
                <Calculator className="h-4 w-4 mr-2" />
                Calcular Ahora
              </Button>
            </div>
            <div className="hidden sm:block">
              <TrendingUp className="h-16 w-16 text-blue-200" />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Quick Actions Grid */}
      <div>
        <h2 className="text-lg font-semibold text-gray-900 mb-4">Acciones Rápidas</h2>
        <div className="grid grid-cols-2 gap-4">
          {quickActions.map((action) => {
            const Icon = action.icon;
            return (
              <Card 
                key={action.path}
                className="cursor-pointer hover:shadow-md transition-shadow"
                onClick={() => setLocation(action.path)}
              >
                <CardContent className="p-4 text-center">
                  <div className={`w-12 h-12 ${action.color} rounded-lg flex items-center justify-center mx-auto mb-3`}>
                    <Icon className="h-6 w-6 text-white" />
                  </div>
                  <h3 className="font-medium text-gray-900 mb-1 text-sm">
                    {action.title}
                  </h3>
                  <p className="text-xs text-gray-600 line-clamp-2">
                    {action.description}
                  </p>
                </CardContent>
              </Card>
            );
          })}
        </div>
      </div>

      {/* tips section */}
      {usuario?.esAdmin && usuario?.cuentaBancaria && (
        <Card className="border-blue-200 bg-blue-50">
          <CardHeader>
            <CardTitle className="text-blue-800 text-base flex items-center gap-2">
              <TrendingUp className="h-4 w-4" />
              Donaciones y Apoyo
            </CardTitle>
          </CardHeader>
          <CardContent className="pt-0">
            <p className="text-sm text-blue-700 mb-2">
              Si te gusta esta herramienta, puedes apoyarnos mediante una donación a la siguiente cuenta:
            </p>
            <pre className="bg-white p-3 rounded border border-blue-100 text-xs font-mono whitespace-pre-wrap text-blue-900">
              {usuario.cuentaBancaria}
            </pre>
          </CardContent>
        </Card>
      )}

      {/* Tips Section */}
      <Card className="border-orange-200 bg-orange-50">
        <CardHeader>
          <CardTitle className="text-orange-800 text-base">
            💡 Consejos de Seguridad
          </CardTitle>
        </CardHeader>
        <CardContent className="pt-0">
          <ul className="text-sm text-orange-700 space-y-2">
            <li>• No llenes tu tanque más del 80% por seguridad</li>
            <li>• Revisa regularmente el estado de las mangueras</li>
            <li>• Mantén el área alrededor del tanque libre de objetos</li>
            <li>• Realiza mantenimiento preventivo cada 6 meses</li>
          </ul>
        </CardContent>
      </Card>
    </div>
  );
}