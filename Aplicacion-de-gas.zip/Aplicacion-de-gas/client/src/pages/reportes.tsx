import { useDashboard } from "@/hooks/use-dashboard";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { TrendingUp, TrendingDown, DollarSign, Users, Calendar, BarChart3 } from "lucide-react";

export default function Reportes() {
  const { data: stats, isLoading } = useDashboard();

  const formatMonto = (monto: string) => {
    const amount = parseFloat(monto);
    return new Intl.NumberFormat('es-AR', {
      style: 'currency',
      currency: 'ARS'
    }).format(amount);
  };

  if (isLoading) {
    return (
      <div className="px-4 py-6 space-y-4">
        {Array.from({ length: 6 }).map((_, i) => (
          <Skeleton key={i} className="h-32 w-full" />
        ))}
      </div>
    );
  }

  const totalPendiente = parseFloat(stats?.totalPendiente || "0");
  const cobradoHoy = parseFloat(stats?.cobradoHoy || "0");
  const vencidos = parseFloat(stats?.vencidos || "0");

  return (
    <div className="px-4 py-6 space-y-6">
      {/* Header */}
      <div className="flex items-center space-x-3">
        <BarChart3 className="h-6 w-6 text-primary" />
        <h1 className="text-2xl font-semibold text-gray-900">Reportes</h1>
      </div>

      {/* Resumen General */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <DollarSign className="h-5 w-5 text-primary" />
            <span>Resumen Financiero</span>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="text-center p-4 bg-gray-50 rounded-lg">
              <p className="text-sm text-gray-600 mb-1">Total por Cobrar</p>
              <p className="text-xl font-mono font-bold text-gray-900">
                {formatMonto(stats?.totalPendiente || "0")}
              </p>
            </div>
            <div className="text-center p-4 bg-success/10 rounded-lg">
              <p className="text-sm text-gray-600 mb-1">Cobrado Hoy</p>
              <p className="text-xl font-mono font-bold text-success">
                {formatMonto(stats?.cobradoHoy || "0")}
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Estado de Cobranzas */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Calendar className="h-5 w-5 text-warning" />
            <span>Estado de Cobranzas</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex items-center justify-between p-3 bg-destructive/10 rounded-lg">
              <div className="flex items-center space-x-3">
                <TrendingDown className="h-5 w-5 text-destructive" />
                <span className="font-medium text-gray-900">Cobros Vencidos</span>
              </div>
              <span className="font-mono font-bold text-destructive">
                {formatMonto(stats?.vencidos || "0")}
              </span>
            </div>
            
            <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
              <div className="flex items-center space-x-3">
                <TrendingUp className="h-5 w-5 text-gray-600" />
                <span className="font-medium text-gray-900">Total Pendiente</span>
              </div>
              <span className="font-mono font-bold text-gray-900">
                {formatMonto(stats?.totalPendiente || "0")}
              </span>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Estadísticas de Clientes */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Users className="h-5 w-5 text-primary" />
            <span>Clientes</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center p-6 bg-primary/10 rounded-lg">
            <p className="text-sm text-gray-600 mb-2">Clientes Activos</p>
            <p className="text-3xl font-bold text-primary">
              {stats?.clientesActivos || 0}
            </p>
          </div>
        </CardContent>
      </Card>

      {/* Métricas de Rendimiento */}
      <Card>
        <CardHeader>
          <CardTitle>Métricas de Rendimiento</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-2 gap-4 text-sm">
            <div>
              <p className="text-gray-600 mb-1">Efectividad de Cobro</p>
              <p className="font-semibold">
                {totalPendiente > 0 
                  ? `${((cobradoHoy / (totalPendiente + cobradoHoy)) * 100).toFixed(1)}%`
                  : "0%"
                }
              </p>
            </div>
            <div>
              <p className="text-gray-600 mb-1">Cobros Vencidos</p>
              <p className="font-semibold">
                {totalPendiente > 0 
                  ? `${((vencidos / totalPendiente) * 100).toFixed(1)}%`
                  : "0%"
                }
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
