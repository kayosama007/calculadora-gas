# Overview

CobrosApp is a scalable web application for managing gas debt collections, built as a full-stack TypeScript application. The system serves as a comprehensive tool for tracking customers, managing debts, recording payments, and calculating gas tank refill costs. It features a mobile-first design optimized for gas collection businesses.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture
- **Framework**: React 18 with TypeScript using Vite as the build tool
- **UI Framework**: Shadcn/ui components built on Radix UI primitives
- **Styling**: Tailwind CSS with CSS variables for theming
- **State Management**: React Context for user authentication, TanStack Query for server state
- **Routing**: Wouter for lightweight client-side routing
- **Forms**: React Hook Form with Zod validation
- **Mobile-First Design**: PWA-ready with responsive design and bottom navigation

## Backend Architecture
- **Runtime**: Node.js with Express.js framework
- **Language**: TypeScript with ES modules
- **API Design**: RESTful API with centralized route handling
- **Middleware**: Custom logging, JSON parsing, and error handling
- **Development**: Hot reload with Vite integration in development mode

## Data Layer
- **Database**: PostgreSQL with Neon serverless connection
- **ORM**: Drizzle ORM for type-safe database operations
- **Schema**: Shared TypeScript types between frontend and backend
- **Validation**: Zod schemas for runtime type checking
- **Migrations**: Drizzle Kit for database migrations

## Key Domain Models
- **Usuarios**: User management and authentication
- **Tanques**: Gas tank registration and tracking
- **Cargas**: Gas refill history and calculations
- **Clientes**: Customer management (referenced in frontend)
- **Cobros**: Debt collection tracking (referenced in frontend)
- **Pagos**: Payment recording (referenced in frontend)

## Authentication & Authorization
- **Strategy**: Email-based authentication with local storage persistence
- **Session Management**: Client-side user context with automatic persistence
- **Route Protection**: Context-based authentication guards

## Core Features
- **Gas Calculator**: Real-time cost calculation for tank refills
- **Tank Management**: Track multiple gas tanks per user
- **History Tracking**: Complete refill history with detailed records
- **Mobile Optimization**: Touch-friendly interface with floating action buttons

# External Dependencies

## Database & Storage
- **Neon Database**: Serverless PostgreSQL hosting
- **Drizzle ORM**: Database toolkit and query builder
- **Connect PG Simple**: PostgreSQL session store

## UI & Styling
- **Radix UI**: Headless component primitives
- **Tailwind CSS**: Utility-first styling framework
- **Lucide React**: Icon library
- **Date-fns**: Date manipulation utilities

## Development Tools
- **Vite**: Build tool and development server
- **TSX**: TypeScript execution for development
- **ESBuild**: Production bundling
- **Replit Plugins**: Development environment integration

## State Management
- **TanStack Query**: Server state management and caching
- **React Hook Form**: Form state and validation
- **Zod**: Schema validation library

## Mobile & PWA
- **Wouter**: Lightweight routing for SPA
- **Embla Carousel**: Touch-friendly carousel component
- **PWA Manifest**: Progressive web app configuration