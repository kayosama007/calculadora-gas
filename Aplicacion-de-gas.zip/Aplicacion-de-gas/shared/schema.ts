import { pgTable, text, serial, integer, boolean, decimal, timestamp } from "drizzle-orm/pg-core";
import { relations } from "drizzle-orm";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Usuarios del sistema de gas
export const usuarios = pgTable("usuarios", {
  id: serial("id").primaryKey(),
  nombre: text("nombre").notNull(),
  email: text("email").notNull().unique(),
  telefono: text("telefono"),
  zona: text("zona"), // Para filtrar pipas cercanas
  ciudad: text("ciudad"),
  calle: text("calle"),
  numero: text("numero"),
  departamento: text("departamento"),
  codigoPostal: text("codigo_postal"),
  esAdmin: boolean("es_admin").default(false),
  passwordAdmin: text("password_admin"), // Contraseña hasheada solo para admin
  fechaRegistro: timestamp("fecha_registro").defaultNow(),
  activo: boolean("activo").default(true),
  aceptoTerminos: boolean("acepto_terminos").default(false),
  cuentaBancaria: text("cuenta_bancaria"), // Información para donaciones
});

// Tanques de gas registrados por usuario
export const tanques = pgTable("tanques", {
  id: serial("id").primaryKey(),
  usuarioId: integer("usuario_id").notNull().references(() => usuarios.id),
  marca: text("marca").notNull(),
  capacidad: text("capacidad").notNull(), // Capacidad en litros
  fechaRegistro: timestamp("fecha_registro").defaultNow(),
  activo: boolean("activo").default(true),
});

// Historial de cargas de gas
export const cargas = pgTable("cargas", {
  id: serial("id").primaryKey(),
  usuarioId: integer("usuario_id").notNull().references(() => usuarios.id),
  tanqueId: integer("tanque_id").notNull().references(() => tanques.id),
  porcentajeAnterior: text("porcentaje_anterior").notNull(),
  porcentajeObjetivo: text("porcentaje_objetivo").notNull(),
  costoPorLitro: text("costo_por_litro").notNull(),
  litrosCargados: text("litros_cargados").notNull(),
  montoTotal: text("monto_total").notNull(),
  fechaCarga: timestamp("fecha_carga").defaultNow(),
  estacion: text("estacion"),
  notas: text("notas"),
});

// Proveedores de gas (pipas registradas por usuarios)
export const proveedores = pgTable("proveedores", {
  id: serial("id").primaryKey(),
  usuarioId: integer("usuario_id").notNull().references(() => usuarios.id),
  nombre: text("nombre").notNull(),
  telefono: text("telefono").notNull(),
  zona: text("zona"),
  ciudad: text("ciudad"),
  codigoPostal: text("codigo_postal"), // Código postal para búsqueda más precisa
  direccion: text("direccion"), // Dirección completa
  barrio: text("barrio"), // Barrio o vecindario
  referencia: text("referencia"), // Referencia de ubicación (ej: cerca del parque, esquina con...)
  coordenadas: text("coordenadas"), // "lat,lng"
  confiable: boolean("confiable").default(false), // Admin puede marcar como confiable
  estrellas: integer("estrellas").default(0), // 0-5 estrellas de confiabilidad del admin
  horarioAtencion: text("horario_atencion"), // Horario de atención
  descripcion: text("descripcion"), // Descripción adicional
  fechaRegistro: timestamp("fecha_registro").defaultNow(),
  activo: boolean("activo").default(true),
});

// Evaluaciones de proveedores
export const evaluaciones = pgTable("evaluaciones", {
  id: serial("id").primaryKey(),
  proveedorId: integer("proveedor_id").notNull().references(() => proveedores.id),
  usuarioId: integer("usuario_id").notNull().references(() => usuarios.id),
  calificacion: integer("calificacion").notNull(), // 1-5
  comentario: text("comentario"),
  recomendado: boolean("recomendado").default(false),
  fechaEvaluacion: timestamp("fecha_evaluacion").defaultNow(),
});

// Gaseras por zonas
export const gaseras = pgTable("gaseras", {
  id: serial("id").primaryKey(),
  nombre: text("nombre").notNull(),
  contacto: text("contacto").notNull(),
  telefono: text("telefono").notNull(),
  zona: text("zona").notNull(),
  ciudad: text("ciudad").notNull(),
  coordenadas: text("coordenadas"), // "lat,lng"
  precioPromedio: decimal("precio_promedio", { precision: 10, scale: 2 }),
  activo: boolean("activo").default(true),
  fechaRegistro: timestamp("fecha_registro").defaultNow(),
});

// Actividad de usuarios en tiempo real
export const actividadUsuarios = pgTable("actividad_usuarios", {
  id: serial("id").primaryKey(),
  usuarioId: integer("usuario_id").notNull().references(() => usuarios.id),
  ultimaActividad: timestamp("ultima_actividad").defaultNow(),
  activo: boolean("activo").default(true),
});

// Relations
export const usuariosRelations = relations(usuarios, ({ many }) => ({
  tanques: many(tanques),
  cargas: many(cargas),
}));

export const tanquesRelations = relations(tanques, ({ one, many }) => ({
  usuario: one(usuarios, {
    fields: [tanques.usuarioId],
    references: [usuarios.id],
  }),
  cargas: many(cargas),
}));

export const cargasRelations = relations(cargas, ({ one }) => ({
  usuario: one(usuarios, {
    fields: [cargas.usuarioId],
    references: [usuarios.id],
  }),
  tanque: one(tanques, {
    fields: [cargas.tanqueId],
    references: [tanques.id],
  }),
}));

export const proveedoresRelations = relations(proveedores, ({ one, many }) => ({
  usuario: one(usuarios, {
    fields: [proveedores.usuarioId],
    references: [usuarios.id],
  }),
  evaluaciones: many(evaluaciones),
}));

export const evaluacionesRelations = relations(evaluaciones, ({ one }) => ({
  proveedor: one(proveedores, {
    fields: [evaluaciones.proveedorId],
    references: [proveedores.id],
  }),
  usuario: one(usuarios, {
    fields: [evaluaciones.usuarioId],
    references: [usuarios.id],
  }),
}));

export const actividadUsuariosRelations = relations(actividadUsuarios, ({ one }) => ({
  usuario: one(usuarios, {
    fields: [actividadUsuarios.usuarioId],
    references: [usuarios.id],
  }),
}));

// Insert schemas
export const insertUsuarioSchema = createInsertSchema(usuarios).omit({
  id: true,
  fechaRegistro: true,
  activo: true,
});

export const insertGaseraSchema = createInsertSchema(gaseras).omit({
  id: true,
  fechaRegistro: true,
  activo: true,
});

export const insertProveedorSchema = createInsertSchema(proveedores).omit({
  id: true,
  fechaRegistro: true,
  activo: true,
  confiable: true,
});

export const insertEvaluacionSchema = createInsertSchema(evaluaciones).omit({
  id: true,
  fechaEvaluacion: true,
});

export const insertTanqueSchema = createInsertSchema(tanques).omit({
  id: true,
  fechaRegistro: true,
  activo: true,
});

export const insertCargaSchema = createInsertSchema(cargas).omit({
  id: true,
  fechaCarga: true,
});

// Types
export type Usuario = typeof usuarios.$inferSelect;
export type InsertUsuario = z.infer<typeof insertUsuarioSchema>;

export type Tanque = typeof tanques.$inferSelect;
export type InsertTanque = z.infer<typeof insertTanqueSchema>;

export type Carga = typeof cargas.$inferSelect;
export type InsertCarga = z.infer<typeof insertCargaSchema>;

export type Gasera = typeof gaseras.$inferSelect;
export type InsertGasera = z.infer<typeof insertGaseraSchema>;

export type Proveedor = typeof proveedores.$inferSelect;
export type InsertProveedor = z.infer<typeof insertProveedorSchema>;

export type Evaluacion = typeof evaluaciones.$inferSelect;
export type InsertEvaluacion = z.infer<typeof insertEvaluacionSchema>;

export type ActividadUsuario = typeof actividadUsuarios.$inferSelect;

export type UsuarioActivo = Usuario & {
  ultimaActividad?: Date | null;
};

export type ProveedorConEvaluaciones = Proveedor & {
  evaluaciones: Evaluacion[];
  promedioCalificacion: number;
  totalEvaluaciones: number;
};

// Extended types for frontend
export type CargaConDetalles = Carga & {
  usuario: Usuario;
  tanque: Tanque;
};

export type TanqueConUsuario = Tanque & {
  usuario: Usuario;
};

export type CalculoCarga = {
  porcentajeActual: number;
  porcentajeObjetivo: number;
  capacidadTanque: number;
  costoPorLitro: number;
  litrosACargar: number;
  montoAPagar: number;
  esSeguro: boolean;
  advertencia?: string;
};

export type CalculoPorDinero = {
  porcentajeActual: number;
  capacidadTanque: number;
  costoPorLitro: number;
  montoAPagar: number;
  litrosPosibles: number;
  porcentajeFinal: number;
  esSeguro: boolean;
  advertencia?: string;
};

export type EstadisticasGas = {
  totalGastado: string;
  cargasRealizadas: number;
  promedioLitrosPorCarga: string;
  estacionMasUsada: string;
};
