import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { db } from "./db";
import { usuarios } from "@shared/schema";
import { insertUsuarioSchema, insertTanqueSchema, insertCargaSchema, insertGaseraSchema, insertProveedorSchema, insertEvaluacionSchema } from "@shared/schema";
import { z } from "zod";
import { eq } from "drizzle-orm";

export async function registerRoutes(app: Express): Promise<Server> {
  // Usuarios routes
  app.get("/api/usuarios", async (req, res) => {
    try {
      const usuarios = await storage.getUsuarios();
      res.json(usuarios);
    } catch (error) {
      res.status(500).json({ message: "Error al obtener usuarios" });
    }
  });

  app.get("/api/usuarios/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const usuario = await storage.getUsuario(id);
      if (!usuario) {
        return res.status(404).json({ message: "Usuario no encontrado" });
      }
      res.json(usuario);
    } catch (error) {
      res.status(500).json({ message: "Error al obtener usuario" });
    }
  });

  app.get("/api/usuarios/email/:email", async (req, res) => {
    try {
      const email = decodeURIComponent(req.params.email);
      console.log("Buscando usuario con email:", email);
      const usuario = await storage.getUsuarioPorEmail(email);
      if (!usuario) {
        return res.status(404).json({ message: "Usuario no encontrado" });
      }
      res.json(usuario);
    } catch (error) {
      console.error("Error al buscar usuario por email:", error);
      res.status(500).json({ message: "Error al obtener usuario", error: error instanceof Error ? error.message : String(error) });
    }
  });

  app.post("/api/usuarios", async (req, res) => {
    try {
      console.log("Creando usuario con datos:", req.body);
      const usuarioData = insertUsuarioSchema.parse(req.body);
      console.log("Datos validados:", usuarioData);
      const usuario = await storage.createUsuario(usuarioData);
      console.log("Usuario creado exitosamente:", usuario);
      res.status(201).json(usuario);
    } catch (error) {
      console.error("Error al crear usuario:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Datos inválidos", errors: error.errors });
      }
      
      // Manejar error de email duplicado
      if (error && typeof error === 'object' && 'code' in error && error.code === '23505') {
        return res.status(409).json({ 
          message: "Ya existe una cuenta con este email", 
          suggestion: "Usa el botón 'Ingresar' para acceder a tu cuenta existente" 
        });
      }
      
      res.status(500).json({ message: "Error al crear usuario", error: error instanceof Error ? error.message : String(error) });
    }
  });

  app.put("/api/usuarios/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const usuarioData = insertUsuarioSchema.partial().parse(req.body);
      const usuario = await storage.updateUsuario(id, usuarioData);
      res.json(usuario);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Datos inválidos", errors: error.errors });
      }
      res.status(500).json({ message: "Error al actualizar usuario" });
    }
  });

  // Tanques routes
  app.get("/api/tanques", async (req, res) => {
    try {
      const tanques = await storage.getTanques();
      res.json(tanques);
    } catch (error) {
      res.status(500).json({ message: "Error al obtener tanques" });
    }
  });

  app.get("/api/tanques/usuario/:usuarioId", async (req, res) => {
    try {
      const usuarioId = parseInt(req.params.usuarioId);
      const tanques = await storage.getTanquesPorUsuario(usuarioId);
      res.json(tanques);
    } catch (error) {
      res.status(500).json({ message: "Error al obtener tanques del usuario" });
    }
  });

  app.get("/api/tanques/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const tanque = await storage.getTanque(id);
      if (!tanque) {
        return res.status(404).json({ message: "Tanque no encontrado" });
      }
      res.json(tanque);
    } catch (error) {
      res.status(500).json({ message: "Error al obtener tanque" });
    }
  });

  app.post("/api/tanques", async (req, res) => {
    try {
      const tanqueData = insertTanqueSchema.parse(req.body);
      const tanque = await storage.createTanque(tanqueData);
      res.status(201).json(tanque);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Datos inválidos", errors: error.errors });
      }
      res.status(500).json({ message: "Error al crear tanque" });
    }
  });

  app.put("/api/tanques/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const tanqueData = insertTanqueSchema.partial().parse(req.body);
      const tanque = await storage.updateTanque(id, tanqueData);
      res.json(tanque);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Datos inválidos", errors: error.errors });
      }
      res.status(500).json({ message: "Error al actualizar tanque" });
    }
  });

  // Cargas routes
  app.get("/api/cargas", async (req, res) => {
    try {
      const cargas = await storage.getCargas();
      res.json(cargas);
    } catch (error) {
      res.status(500).json({ message: "Error al obtener cargas" });
    }
  });

  app.get("/api/cargas/usuario/:usuarioId", async (req, res) => {
    try {
      const usuarioId = parseInt(req.params.usuarioId);
      const cargas = await storage.getCargasPorUsuario(usuarioId);
      res.json(cargas);
    } catch (error) {
      res.status(500).json({ message: "Error al obtener cargas del usuario" });
    }
  });

  app.post("/api/cargas", async (req, res) => {
    try {
      const cargaData = insertCargaSchema.parse(req.body);
      const carga = await storage.createCarga(cargaData);
      res.status(201).json(carga);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Datos inválidos", errors: error.errors });
      }
      res.status(500).json({ message: "Error al crear carga" });
    }
  });

  // Cálculos routes
  app.post("/api/calcular", async (req, res) => {
    try {
      const { porcentajeActual, porcentajeObjetivo, capacidadTanque, costoPorLitro } = req.body;
      
      // Validar que todos los campos estén presentes
      if (porcentajeActual === undefined || porcentajeObjetivo === undefined || 
          capacidadTanque === undefined || costoPorLitro === undefined) {
        return res.status(400).json({ message: "Faltan datos requeridos para el cálculo" });
      }

      const calculo = storage.calcularCarga(
        parseFloat(porcentajeActual),
        parseFloat(porcentajeObjetivo),
        parseFloat(capacidadTanque),
        parseFloat(costoPorLitro)
      );
      
      res.json(calculo);
    } catch (error) {
      res.status(500).json({ message: "Error al calcular carga" });
    }
  });

  app.post("/api/calcular-por-dinero", async (req, res) => {
    try {
      const { porcentajeActual, capacidadTanque, costoPorLitro, montoAPagar } = req.body;
      
      // Validar que todos los campos estén presentes
      if (porcentajeActual === undefined || capacidadTanque === undefined || 
          costoPorLitro === undefined || montoAPagar === undefined) {
        return res.status(400).json({ message: "Faltan datos requeridos para el cálculo por dinero" });
      }

      const calculo = storage.calcularPorDinero(
        parseFloat(porcentajeActual),
        parseFloat(capacidadTanque),
        parseFloat(costoPorLitro),
        parseFloat(montoAPagar)
      );
      
      res.json(calculo);
    } catch (error) {
      res.status(500).json({ message: "Error al calcular por dinero" });
    }
  });

  // Estadísticas routes
  app.get("/api/estadisticas/usuario/:usuarioId", async (req, res) => {
    try {
      const usuarioId = parseInt(req.params.usuarioId);
      const estadisticas = await storage.getEstadisticasPorUsuario(usuarioId);
      res.json(estadisticas);
    } catch (error) {
      res.status(500).json({ message: "Error al obtener estadísticas" });
    }
  });

  // Admin routes
  app.get("/api/admin/usuarios", async (req, res) => {
    try {
      const usuarios = await storage.getUsuarios();
      res.json(usuarios);
    } catch (error) {
      res.status(500).json({ message: "Error al obtener usuarios" });
    }
  });

  app.put("/api/admin/usuarios/:id/admin", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const { esAdmin } = req.body;
      const usuario = await storage.updateUsuario(id, { esAdmin });
      res.json(usuario);
    } catch (error) {
      res.status(500).json({ message: "Error al actualizar usuario" });
    }
  });

  app.delete("/api/admin/usuarios/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const [usuario] = await db.update(usuarios).set({ activo: false }).where(eq(usuarios.id, id)).returning();
      res.json(usuario);
    } catch (error) {
      res.status(500).json({ message: "Error al desactivar usuario" });
    }
  });

  // Gaseras routes
  app.get("/api/gaseras", async (req, res) => {
    try {
      const gaseras = await storage.getGaseras();
      res.json(gaseras);
    } catch (error) {
      res.status(500).json({ message: "Error al obtener gaseras" });
    }
  });

  app.get("/api/gaseras/zona/:zona", async (req, res) => {
    try {
      const zona = decodeURIComponent(req.params.zona);
      const gaseras = await storage.getGaserasPorZona(zona);
      res.json(gaseras);
    } catch (error) {
      res.status(500).json({ message: "Error al obtener gaseras por zona" });
    }
  });

  app.post("/api/admin/gaseras", async (req, res) => {
    try {
      const gasera = insertGaseraSchema.parse(req.body);
      const newGasera = await storage.createGasera(gasera);
      res.json(newGasera);
    } catch (error) {
      res.status(400).json({ message: "Error al crear gasera" });
    }
  });

  // Usuarios activos y actividad
  app.get("/api/admin/usuarios-activos", async (req, res) => {
    try {
      const usuariosActivos = await storage.getUsuariosActivos();
      res.json(usuariosActivos);
    } catch (error) {
      res.status(500).json({ message: "Error al obtener usuarios activos" });
    }
  });

  app.post("/api/actividad", async (req, res) => {
    try {
      const { usuarioId } = req.body;
      if (!usuarioId) return res.status(400).json({ message: "usuarioId requerido" });
      await storage.updateActividadUsuario(usuarioId);
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ message: "Error al actualizar actividad" });
    }
  });

  // Eliminar usuarios viejos
  app.post("/api/admin/limpiar-usuarios", async (req, res) => {
    try {
      const { diasInactivos } = req.body;
      if (!diasInactivos || diasInactivos < 1) {
        return res.status(400).json({ message: "diasInactivos debe ser mayor a 0" });
      }
      const eliminados = await storage.eliminarUsuariosViejos(diasInactivos);
      res.json({ eliminados, message: `${eliminados} usuarios desactivados` });
    } catch (error) {
      res.status(500).json({ message: "Error al limpiar usuarios" });
    }
  });

  // Eliminar usuario permanentemente
  app.delete("/api/admin/usuarios/:id/permanent", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      await storage.eliminarUsuarioPermanentemente(id);
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ message: "Error al eliminar usuario" });
    }
  });

  // Proveedores routes
  app.get("/api/proveedores", async (req, res) => {
    try {
      const proveedores = await storage.getProveedores();
      res.json(proveedores);
    } catch (error) {
      res.status(500).json({ message: "Error al obtener proveedores" });
    }
  });

  app.get("/api/proveedores/zona/:zona", async (req, res) => {
    try {
      const zona = decodeURIComponent(req.params.zona);
      const proveedores = await storage.getProveedoresPorZona(zona);
      res.json(proveedores);
    } catch (error) {
      res.status(500).json({ message: "Error al obtener proveedores" });
    }
  });

  app.get("/api/proveedores/cercanos", async (req, res) => {
    try {
      const zona = req.query.zona as string | undefined;
      const ciudad = req.query.ciudad as string | undefined;
      const codigoPostal = req.query.codigoPostal as string | undefined;
      const proveedores = await storage.getProveedoresCercanos(zona, ciudad, codigoPostal);
      res.json(proveedores);
    } catch (error) {
      res.status(500).json({ message: "Error al obtener proveedores cercanos" });
    }
  });

  app.post("/api/proveedores", async (req, res) => {
    try {
      const proveedor = insertProveedorSchema.parse(req.body);
      const newProveedor = await storage.createProveedor(proveedor);
      res.json(newProveedor);
    } catch (error) {
      res.status(400).json({ message: "Error al crear proveedor" });
    }
  });

  // Evaluaciones routes
  app.post("/api/evaluaciones", async (req, res) => {
    try {
      const evaluacion = insertEvaluacionSchema.parse(req.body);
      const newEval = await storage.createEvaluacion(evaluacion);
      res.json(newEval);
    } catch (error) {
      res.status(400).json({ message: "Error al crear evaluación" });
    }
  });

  app.get("/api/evaluaciones/:proveedorId", async (req, res) => {
    try {
      const proveedorId = parseInt(req.params.proveedorId);
      const evals = await storage.getEvaluacionesPorProveedor(proveedorId);
      res.json(evals);
    } catch (error) {
      res.status(500).json({ message: "Error al obtener evaluaciones" });
    }
  });

  // Admin - Marcar proveedor como confiable
  app.put("/api/admin/proveedores/:id/confiable", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const { confiable } = req.body;
      const proveedor = await storage.updateProveedorConfiable(id, confiable);
      res.json(proveedor);
    } catch (error) {
      res.status(500).json({ message: "Error al actualizar proveedor" });
    }
  });

  // Eliminar proveedor
  app.delete("/api/proveedores/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      await storage.deleteProveedor(id);
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ message: "Error al eliminar proveedor" });
    }
  });

  // Admin - Actualizar estrellas de confiabilidad
  app.put("/api/admin/proveedores/:id/estrellas", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const { estrellas } = req.body;
      if (estrellas < 0 || estrellas > 5) {
        return res.status(400).json({ message: "Las estrellas deben estar entre 0 y 5" });
      }
      const proveedor = await storage.updateProveedorEstrellas(id, estrellas);
      res.json(proveedor);
    } catch (error) {
      res.status(500).json({ message: "Error al actualizar estrellas" });
    }
  });

  // Admin - Eliminar proveedor
  app.delete("/api/admin/proveedores/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      await storage.deleteProveedor(id);
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ message: "Error al eliminar proveedor" });
    }
  });

  // Admin - Verificar contraseña
  app.post("/api/admin/verify-password", async (req, res) => {
    try {
      const { usuarioId, password } = req.body;
      if (!usuarioId || !password) {
        return res.status(400).json({ message: "Datos incompletos" });
      }
      const isValid = await storage.verifyAdminPassword(usuarioId, password);
      res.json({ valid: isValid });
    } catch (error) {
      res.status(500).json({ message: "Error al verificar contraseña" });
    }
  });

  // Admin - Establecer contraseña
  app.post("/api/admin/set-password", async (req, res) => {
    try {
      const { usuarioId, password } = req.body;
      if (!usuarioId || !password || password.length < 4) {
        return res.status(400).json({ message: "Contraseña debe tener al menos 4 caracteres" });
      }
      await storage.setAdminPassword(usuarioId, password);
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ message: "Error al establecer contraseña" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}