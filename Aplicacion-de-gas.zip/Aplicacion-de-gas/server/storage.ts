import { usuarios, tanques, cargas, gaseras, actividadUsuarios, proveedores, evaluaciones, type Usuario, type InsertUsuario, type Tanque, type InsertTanque, type Carga, type InsertCarga, type CargaConDetalles, type TanqueConUsuario, type EstadisticasGas, type CalculoCarga, type CalculoPorDinero, type Gasera, type InsertGasera, type UsuarioActivo, type Proveedor, type InsertProveedor, type Evaluacion, type InsertEvaluacion, type ProveedorConEvaluaciones } from "@shared/schema";
import { db } from "./db";
import { eq, desc, sql, and, sum, gte, avg } from "drizzle-orm";
import crypto from "crypto";

export interface IStorage {
  // Usuarios
  getUsuarios(): Promise<Usuario[]>;
  getUsuario(id: number): Promise<Usuario | undefined>;
  getUsuarioPorEmail(email: string): Promise<Usuario | undefined>;
  createUsuario(usuario: InsertUsuario): Promise<Usuario>;
  updateUsuario(id: number, usuario: Partial<InsertUsuario>): Promise<Usuario>;

  // Tanques
  getTanques(): Promise<TanqueConUsuario[]>;
  getTanquesPorUsuario(usuarioId: number): Promise<Tanque[]>;
  getTanque(id: number): Promise<Tanque | undefined>;
  createTanque(tanque: InsertTanque): Promise<Tanque>;
  updateTanque(id: number, tanque: Partial<InsertTanque>): Promise<Tanque>;

  // Cargas
  getCargas(): Promise<CargaConDetalles[]>;
  getCargasPorUsuario(usuarioId: number): Promise<CargaConDetalles[]>;
  createCarga(carga: InsertCarga): Promise<Carga>;

  // Cálculos
  calcularCarga(
    porcentajeActual: number, 
    porcentajeObjetivo: number, 
    capacidadTanque: number, 
    costoPorLitro: number
  ): CalculoCarga;
  
  calcularPorDinero(
    porcentajeActual: number,
    capacidadTanque: number,
    costoPorLitro: number,
    montoAPagar: number
  ): CalculoPorDinero;

  // Estadísticas
  getEstadisticasPorUsuario(usuarioId: number): Promise<EstadisticasGas>;

  // Gaseras
  getGaseras(): Promise<Gasera[]>;
  getGaserasPorZona(zona: string): Promise<Gasera[]>;
  createGasera(gasera: InsertGasera): Promise<Gasera>;

  // Actividad de usuarios
  getUsuariosActivos(): Promise<UsuarioActivo[]>;
  updateActividadUsuario(usuarioId: number): Promise<void>;

  // Limpieza de usuarios viejos
  eliminarUsuariosViejos(diasInactivos: number): Promise<number>;

  // Eliminar usuario permanentemente
  eliminarUsuarioPermanentemente(id: number): Promise<void>;

  // Proveedores
  getProveedores(): Promise<ProveedorConEvaluaciones[]>;
  getProveedoresPorZona(zona: string): Promise<ProveedorConEvaluaciones[]>;
  getProveedoresCercanos(zona?: string, ciudad?: string, codigoPostal?: string): Promise<ProveedorConEvaluaciones[]>;
  createProveedor(proveedor: InsertProveedor): Promise<Proveedor>;
  updateProveedorConfiable(id: number, confiable: boolean): Promise<Proveedor>;

  // Evaluaciones
  createEvaluacion(evaluacion: InsertEvaluacion): Promise<Evaluacion>;
  getEvaluacionesPorProveedor(proveedorId: number): Promise<Evaluacion[]>;

  // Eliminar proveedor
  deleteProveedor(id: number): Promise<void>;

  // Actualizar estrellas de confiabilidad
  updateProveedorEstrellas(id: number, estrellas: number): Promise<Proveedor>;

  // Admin password
  setAdminPassword(usuarioId: number, password: string): Promise<void>;
  verifyAdminPassword(usuarioId: number, password: string): Promise<boolean>;
}

export class DatabaseStorage implements IStorage {
  // Usuarios
  async getUsuarios(): Promise<Usuario[]> {
    return await db.select().from(usuarios).where(eq(usuarios.activo, true)).orderBy(desc(usuarios.fechaRegistro));
  }

  async getUsuario(id: number): Promise<Usuario | undefined> {
    const [usuario] = await db.select().from(usuarios).where(eq(usuarios.id, id));
    return usuario || undefined;
  }

  async getUsuarioPorEmail(email: string): Promise<Usuario | undefined> {
    const [usuario] = await db.select().from(usuarios).where(eq(usuarios.email, email));
    return usuario || undefined;
  }

  async createUsuario(usuario: InsertUsuario): Promise<Usuario> {
    const [newUsuario] = await db.insert(usuarios).values(usuario).returning();
    return newUsuario;
  }

  async updateUsuario(id: number, usuario: Partial<InsertUsuario>): Promise<Usuario> {
    const [updatedUsuario] = await db
      .update(usuarios)
      .set(usuario)
      .where(eq(usuarios.id, id))
      .returning();
    return updatedUsuario;
  }

  // Tanques
  async getTanques(): Promise<TanqueConUsuario[]> {
    const results = await db
      .select({
        id: tanques.id,
        usuarioId: tanques.usuarioId,
        marca: tanques.marca,
        capacidad: tanques.capacidad,
        fechaRegistro: tanques.fechaRegistro,
        activo: tanques.activo,
        usuario: {
          id: usuarios.id,
          nombre: usuarios.nombre,
          email: usuarios.email,
          telefono: usuarios.telefono,
          esAdmin: usuarios.esAdmin,
          cuentaBancaria: usuarios.cuentaBancaria,
          fechaRegistro: usuarios.fechaRegistro,
          activo: usuarios.activo,
          zona: usuarios.zona,
          ciudad: usuarios.ciudad,
          calle: usuarios.calle,
          numero: usuarios.numero,
          departamento: usuarios.departamento,
          codigoPostal: usuarios.codigoPostal,
          aceptoTerminos: usuarios.aceptoTerminos,
        }
      })
      .from(tanques)
      .innerJoin(usuarios, eq(tanques.usuarioId, usuarios.id))
      .where(eq(tanques.activo, true))
      .orderBy(desc(tanques.fechaRegistro));
    
    return results.map(row => ({
      ...row,
      usuario: row.usuario
    }));
  }

  async getTanquesPorUsuario(usuarioId: number): Promise<Tanque[]> {
    return await db
      .select()
      .from(tanques)
      .where(and(eq(tanques.usuarioId, usuarioId), eq(tanques.activo, true)))
      .orderBy(desc(tanques.fechaRegistro));
  }

  async getTanque(id: number): Promise<Tanque | undefined> {
    const [tanque] = await db.select().from(tanques).where(eq(tanques.id, id));
    return tanque || undefined;
  }

  async createTanque(tanque: InsertTanque): Promise<Tanque> {
    const [newTanque] = await db.insert(tanques).values(tanque).returning();
    return newTanque;
  }

  async updateTanque(id: number, tanque: Partial<InsertTanque>): Promise<Tanque> {
    const [updatedTanque] = await db
      .update(tanques)
      .set(tanque)
      .where(eq(tanques.id, id))
      .returning();
    return updatedTanque;
  }

  // Cargas
  async getCargas(): Promise<CargaConDetalles[]> {
    const results = await db
      .select({
        id: cargas.id,
        usuarioId: cargas.usuarioId,
        tanqueId: cargas.tanqueId,
        porcentajeAnterior: cargas.porcentajeAnterior,
        porcentajeObjetivo: cargas.porcentajeObjetivo,
        costoPorLitro: cargas.costoPorLitro,
        litrosCargados: cargas.litrosCargados,
        montoTotal: cargas.montoTotal,
        fechaCarga: cargas.fechaCarga,
        estacion: cargas.estacion,
        notas: cargas.notas,
        usuario: {
          id: usuarios.id,
          nombre: usuarios.nombre,
          email: usuarios.email,
          telefono: usuarios.telefono,
          esAdmin: usuarios.esAdmin,
          cuentaBancaria: usuarios.cuentaBancaria,
          fechaRegistro: usuarios.fechaRegistro,
          activo: usuarios.activo,
          zona: usuarios.zona,
          ciudad: usuarios.ciudad,
          calle: usuarios.calle,
          numero: usuarios.numero,
          departamento: usuarios.departamento,
          codigoPostal: usuarios.codigoPostal,
          aceptoTerminos: usuarios.aceptoTerminos,
          passwordAdmin: usuarios.passwordAdmin,
        },
        tanque: {
          id: tanques.id,
          usuarioId: tanques.usuarioId,
          marca: tanques.marca,
          capacidad: tanques.capacidad,
          fechaRegistro: tanques.fechaRegistro,
          activo: tanques.activo,
        }
      })
      .from(cargas)
      .innerJoin(usuarios, eq(cargas.usuarioId, usuarios.id))
      .innerJoin(tanques, eq(cargas.tanqueId, tanques.id))
      .orderBy(desc(cargas.fechaCarga));
    
    return results.map(row => ({
      ...row,
      usuario: row.usuario,
      tanque: row.tanque
    }));
  }

  async getCargasPorUsuario(usuarioId: number): Promise<CargaConDetalles[]> {
    const results = await db
      .select({
        id: cargas.id,
        usuarioId: cargas.usuarioId,
        tanqueId: cargas.tanqueId,
        porcentajeAnterior: cargas.porcentajeAnterior,
        porcentajeObjetivo: cargas.porcentajeObjetivo,
        costoPorLitro: cargas.costoPorLitro,
        litrosCargados: cargas.litrosCargados,
        montoTotal: cargas.montoTotal,
        fechaCarga: cargas.fechaCarga,
        estacion: cargas.estacion,
        notas: cargas.notas,
        usuario: {
          id: usuarios.id,
          nombre: usuarios.nombre,
          email: usuarios.email,
          telefono: usuarios.telefono,
          esAdmin: usuarios.esAdmin,
          cuentaBancaria: usuarios.cuentaBancaria,
          fechaRegistro: usuarios.fechaRegistro,
          activo: usuarios.activo,
          zona: usuarios.zona,
          ciudad: usuarios.ciudad,
          calle: usuarios.calle,
          numero: usuarios.numero,
          departamento: usuarios.departamento,
          codigoPostal: usuarios.codigoPostal,
          aceptoTerminos: usuarios.aceptoTerminos,
          passwordAdmin: usuarios.passwordAdmin,
        },
        tanque: {
          id: tanques.id,
          usuarioId: tanques.usuarioId,
          marca: tanques.marca,
          capacidad: tanques.capacidad,
          fechaRegistro: tanques.fechaRegistro,
          activo: tanques.activo,
        }
      })
      .from(cargas)
      .innerJoin(usuarios, eq(cargas.usuarioId, usuarios.id))
      .innerJoin(tanques, eq(cargas.tanqueId, tanques.id))
      .where(eq(cargas.usuarioId, usuarioId))
      .orderBy(desc(cargas.fechaCarga));
    
    return results.map(row => ({
      ...row,
      usuario: row.usuario,
      tanque: row.tanque
    }));
  }

  async createCarga(carga: InsertCarga): Promise<Carga> {
    const [newCarga] = await db.insert(cargas).values(carga).returning();
    return newCarga;
  }

  // Cálculos
  calcularCarga(
    porcentajeActual: number, 
    porcentajeObjetivo: number, 
    capacidadTanque: number, 
    costoPorLitro: number
  ): CalculoCarga {
    // Validaciones de seguridad
    let esSeguro = true;
    let advertencia: string | undefined;

    if (porcentajeObjetivo > 80) {
      esSeguro = false;
      advertencia = "⚠️ ADVERTENCIA: No se recomienda llenar el tanque más del 80% por seguridad";
    }

    if (porcentajeObjetivo > 85) {
      advertencia = "🚨 PELIGRO: Llenar más del 85% puede ser muy peligroso";
    }

    if (porcentajeActual >= porcentajeObjetivo) {
      advertencia = "El tanque ya tiene más gas del objetivo solicitado";
    }

    // Cálculos
    const porcentajeACargar = porcentajeObjetivo - porcentajeActual;
    const litrosACargar = (capacidadTanque * porcentajeACargar) / 100;
    const montoAPagar = litrosACargar * costoPorLitro;

    return {
      porcentajeActual,
      porcentajeObjetivo,
      capacidadTanque,
      costoPorLitro,
      litrosACargar: Math.max(0, litrosACargar),
      montoAPagar: Math.max(0, montoAPagar),
      esSeguro,
      advertencia
    };
  }

  calcularPorDinero(
    porcentajeActual: number,
    capacidadTanque: number,
    costoPorLitro: number,
    montoAPagar: number
  ): CalculoPorDinero {
    // Cálculos básicos
    const litrosPosibles = montoAPagar / costoPorLitro;
    const porcentajeACargar = (litrosPosibles / capacidadTanque) * 100;
    const porcentajeFinal = porcentajeActual + porcentajeACargar;

    // Validaciones de seguridad
    let esSeguro = true;
    let advertencia: string | undefined;

    if (porcentajeFinal > 100) {
      advertencia = "⚠️ ADVERTENCIA: Con ese dinero el tanque se desbordaría y excede del límite de gas que le cabe al tanque. Reduce la cantidad.";
      esSeguro = false;
    } else if (porcentajeFinal > 85) {
      advertencia = "🚨 PELIGRO: Llenar más del 85% puede ser muy peligroso";
      esSeguro = false;
    } else if (porcentajeFinal > 80) {
      advertencia = "⚠️ ADVERTENCIA: No se recomienda llenar el tanque más del 80% por seguridad";
      esSeguro = false;
    }

    if (litrosPosibles <= 0) {
      advertencia = "El monto ingresado es insuficiente para comprar gas";
      esSeguro = false;
    }

    return {
      porcentajeActual,
      capacidadTanque,
      costoPorLitro,
      montoAPagar,
      litrosPosibles: Math.max(0, litrosPosibles),
      porcentajeFinal: Math.min(100, Math.max(porcentajeActual, porcentajeFinal)),
      esSeguro,
      advertencia
    };
  }

  // Estadísticas
  // Gaseras
  async getGaseras(): Promise<Gasera[]> {
    return await db.select().from(gaseras).where(eq(gaseras.activo, true)).orderBy(desc(gaseras.fechaRegistro));
  }

  async getGaserasPorZona(zona: string): Promise<Gasera[]> {
    return await db.select().from(gaseras).where(and(eq(gaseras.zona, zona), eq(gaseras.activo, true)));
  }

  async createGasera(gasera: InsertGasera): Promise<Gasera> {
    const [newGasera] = await db.insert(gaseras).values(gasera).returning();
    return newGasera;
  }

  // Actividad de usuarios
  async getUsuariosActivos(): Promise<UsuarioActivo[]> {
    const results = await db
      .select({
        id: usuarios.id,
        nombre: usuarios.nombre,
        email: usuarios.email,
        telefono: usuarios.telefono,
        esAdmin: usuarios.esAdmin,
        fechaRegistro: usuarios.fechaRegistro,
        activo: usuarios.activo,
        cuentaBancaria: usuarios.cuentaBancaria,
        zona: usuarios.zona,
        ciudad: usuarios.ciudad,
        calle: usuarios.calle,
        numero: usuarios.numero,
        departamento: usuarios.departamento,
        codigoPostal: usuarios.codigoPostal,
        aceptoTerminos: usuarios.aceptoTerminos,
        passwordAdmin: usuarios.passwordAdmin,
        ultimaActividad: actividadUsuarios.ultimaActividad,
      })
      .from(usuarios)
      .leftJoin(actividadUsuarios, eq(usuarios.id, actividadUsuarios.usuarioId))
      .where(eq(usuarios.activo, true))
      .orderBy(desc(actividadUsuarios.ultimaActividad));
    return results as UsuarioActivo[];
  }

  async updateActividadUsuario(usuarioId: number): Promise<void> {
    const [existing] = await db
      .select()
      .from(actividadUsuarios)
      .where(eq(actividadUsuarios.usuarioId, usuarioId));

    if (existing) {
      await db
        .update(actividadUsuarios)
        .set({ ultimaActividad: new Date() })
        .where(eq(actividadUsuarios.usuarioId, usuarioId));
    } else {
      await db.insert(actividadUsuarios).values({ usuarioId, ultimaActividad: new Date() });
    }
  }

  async eliminarUsuariosViejos(diasInactivos: number): Promise<number> {
    const fechaLimite = new Date();
    fechaLimite.setDate(fechaLimite.getDate() - diasInactivos);

    const result = await db
      .update(usuarios)
      .set({ activo: false })
      .where(and(
        eq(usuarios.activo, true),
        eq(usuarios.esAdmin, false),
        sql`${usuarios.fechaRegistro} < ${fechaLimite}`
      ))
      .returning();

    return result.length;
  }

  async eliminarUsuarioPermanentemente(id: number): Promise<void> {
    await db.delete(usuarios).where(eq(usuarios.id, id));
  }

  async getProveedores(): Promise<ProveedorConEvaluaciones[]> {
    const provs = await db.select().from(proveedores).where(eq(proveedores.activo, true)).orderBy(desc(proveedores.fechaRegistro));
    
    return Promise.all(provs.map(async (prov) => {
      const evals = await db.select().from(evaluaciones).where(eq(evaluaciones.proveedorId, prov.id));
      const promedio = evals.length > 0 ? evals.reduce((sum, e) => sum + e.calificacion, 0) / evals.length : 0;
      return {
        ...prov,
        evaluaciones: evals,
        promedioCalificacion: parseFloat(promedio.toFixed(1)),
        totalEvaluaciones: evals.length,
      };
    }));
  }

  async getProveedoresPorZona(zona: string): Promise<ProveedorConEvaluaciones[]> {
    const provs = await db.select().from(proveedores).where(and(eq(proveedores.zona, zona), eq(proveedores.activo, true)));
    
    return Promise.all(provs.map(async (prov) => {
      const evals = await db.select().from(evaluaciones).where(eq(evaluaciones.proveedorId, prov.id));
      const promedio = evals.length > 0 ? evals.reduce((sum, e) => sum + e.calificacion, 0) / evals.length : 0;
      return {
        ...prov,
        evaluaciones: evals,
        promedioCalificacion: parseFloat(promedio.toFixed(1)),
        totalEvaluaciones: evals.length,
      };
    }));
  }

  async getProveedoresCercanos(zona?: string, ciudad?: string, codigoPostal?: string): Promise<ProveedorConEvaluaciones[]> {
    const conditions = [];
    if (zona) conditions.push(eq(proveedores.zona, zona));
    if (ciudad) conditions.push(eq(proveedores.ciudad, ciudad));
    if (codigoPostal) conditions.push(eq(proveedores.codigoPostal, codigoPostal));
    
    const where = conditions.length > 0 ? and(eq(proveedores.activo, true), and(...conditions)) : eq(proveedores.activo, true);
    
    const provs = await db.select().from(proveedores).where(where).orderBy(desc(proveedores.estrellas), desc(proveedores.fechaRegistro));
    
    return Promise.all(provs.map(async (prov) => {
      const evals = await db.select().from(evaluaciones).where(eq(evaluaciones.proveedorId, prov.id));
      const promedio = evals.length > 0 ? evals.reduce((sum, e) => sum + e.calificacion, 0) / evals.length : 0;
      return {
        ...prov,
        evaluaciones: evals,
        promedioCalificacion: parseFloat(promedio.toFixed(1)),
        totalEvaluaciones: evals.length,
      };
    }));
  }

  async createProveedor(proveedor: InsertProveedor): Promise<Proveedor> {
    const [newProveedor] = await db.insert(proveedores).values(proveedor).returning();
    return newProveedor;
  }

  async updateProveedorConfiable(id: number, confiable: boolean): Promise<Proveedor> {
    const [updated] = await db.update(proveedores).set({ confiable }).where(eq(proveedores.id, id)).returning();
    return updated;
  }

  async createEvaluacion(evaluacion: InsertEvaluacion): Promise<Evaluacion> {
    const [newEval] = await db.insert(evaluaciones).values(evaluacion).returning();
    return newEval;
  }

  async getEvaluacionesPorProveedor(proveedorId: number): Promise<Evaluacion[]> {
    return await db.select().from(evaluaciones).where(eq(evaluaciones.proveedorId, proveedorId)).orderBy(desc(evaluaciones.fechaEvaluacion));
  }

  async deleteProveedor(id: number): Promise<void> {
    await db.delete(proveedores).where(eq(proveedores.id, id));
  }

  async updateProveedorEstrellas(id: number, estrellas: number): Promise<Proveedor> {
    const [proveedor] = await db.update(proveedores).set({ estrellas }).where(eq(proveedores.id, id)).returning();
    return proveedor;
  }

  async setAdminPassword(usuarioId: number, password: string): Promise<void> {
    const hashedPassword = crypto.createHash("sha256").update(password).digest("hex");
    await db.update(usuarios).set({ passwordAdmin: hashedPassword }).where(eq(usuarios.id, usuarioId));
  }

  async verifyAdminPassword(usuarioId: number, password: string): Promise<boolean> {
    const usuario = await this.getUsuario(usuarioId);
    if (!usuario?.passwordAdmin) return false;
    const hashedPassword = crypto.createHash("sha256").update(password).digest("hex");
    return usuario.passwordAdmin === hashedPassword;
  }

  async getEstadisticasPorUsuario(usuarioId: number): Promise<EstadisticasGas> {
    // Total gastado
    const [totalGastadoResult] = await db
      .select({ total: sql<string>`COALESCE(SUM(${cargas.montoTotal}), 0)` })
      .from(cargas)
      .where(eq(cargas.usuarioId, usuarioId));

    // Número de cargas
    const [cargasRealizadasResult] = await db
      .select({ count: sql<number>`COUNT(*)` })
      .from(cargas)
      .where(eq(cargas.usuarioId, usuarioId));

    // Promedio de litros por carga
    const [promedioLitrosResult] = await db
      .select({ promedio: sql<string>`COALESCE(AVG(${cargas.litrosCargados}), 0)` })
      .from(cargas)
      .where(eq(cargas.usuarioId, usuarioId));

    // Estación más usada
    const [estacionMasUsadaResult] = await db
      .select({ 
        estacion: cargas.estacion,
        count: sql<number>`COUNT(*)` 
      })
      .from(cargas)
      .where(eq(cargas.usuarioId, usuarioId))
      .groupBy(cargas.estacion)
      .orderBy(desc(sql<number>`COUNT(*)`))
      .limit(1);

    return {
      totalGastado: totalGastadoResult?.total || "0",
      cargasRealizadas: cargasRealizadasResult?.count || 0,
      promedioLitrosPorCarga: promedioLitrosResult?.promedio || "0",
      estacionMasUsada: estacionMasUsadaResult?.estacion || "Sin datos"
    };
  }
}

export const storage = new DatabaseStorage();